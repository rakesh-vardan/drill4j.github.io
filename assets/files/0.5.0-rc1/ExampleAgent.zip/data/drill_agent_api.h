#ifndef KONAN_DRILL_AGENT_H
#define KONAN_DRILL_AGENT_H
#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
typedef bool            drill_agent_KBoolean;
#else
typedef _Bool           drill_agent_KBoolean;
#endif
typedef unsigned short     drill_agent_KChar;
typedef signed char        drill_agent_KByte;
typedef short              drill_agent_KShort;
typedef int                drill_agent_KInt;
typedef long long          drill_agent_KLong;
typedef unsigned char      drill_agent_KUByte;
typedef unsigned short     drill_agent_KUShort;
typedef unsigned int       drill_agent_KUInt;
typedef unsigned long long drill_agent_KULong;
typedef float              drill_agent_KFloat;
typedef double             drill_agent_KDouble;
typedef void*              drill_agent_KNativePtr;
struct drill_agent_KType;
typedef struct drill_agent_KType drill_agent_KType;

typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Byte;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Short;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Int;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Long;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Float;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Double;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Char;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Boolean;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Unit;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_common_AgentType;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_AgentPluginData;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_collections_Map;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_plugin_api_processing_NativePart;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_plugin_DrillRequest;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_cinterop_CValuesRef;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_DI;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_common_ws_URL;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_common_AgentConfig;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_collections_MutableMap;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_collections_List;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_agent_JavaProcess;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_agent_Gaps;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_collections_MutableList;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Any;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_concurrency_BackgroundThread;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_coroutines_CoroutineContext;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_coroutines_SuspendFunction0;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_coroutines_Job;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_exceptions_PluginLoadException;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_exceptions_WsClosedException;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_mu_KLogger;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_common_PluginMetadata;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_plugin_api_processing_AgentPart;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_serialization_SerializationConstructorMarker;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_$serializer;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_serialization_SerialDescriptor;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Array;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_serialization_Decoder;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_serialization_Encoder;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_Companion;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_serialization_KSerializer;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_$serializer;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_Companion;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_plugin_api_processing_UnloadReason;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_common_PluginConfig;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_plugin_loader_InstrumentationNativePlugin;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_ByteArray;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_plugin_PluginManager;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_common_Family;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_coroutines_channels_Channel;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_coroutines_Deferred;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_coroutines_CoroutineScope;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncStreamBase;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_WsRouter;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_WsRouter_inners;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_coroutines_SuspendFunction1;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncBaseStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncCloseable;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncCloseable_Companion;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncGetLengthStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncGetPositionStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncInputStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncInputStreamWithLength;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncInvokable;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncLengthStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncOutputStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncPositionLengthStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncPositionStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncRAInputStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncRAOutputStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncThread;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_InfoTopic;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_MemoryAsyncStreamBase;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_PluginTopic;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_coroutines_SuspendFunction2;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_Sender;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_Topic;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Function1;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_WsSocket;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_crypto_HashFactory;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_crypto_Hash;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Function0;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_crypto_MD5;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_crypto_MD5_Companion;

extern void* JNIEn();
extern void* JNIFun();
extern void addPluginToRegistry(drill_agent_kref_com_epam_drill_plugin_api_processing_NativePart plugin);
extern void* currentThread();
extern void disableJvmtiEventBreakpoint(void* thread);
extern void disableJvmtiEventClassFileLoadHook(void* thread);
extern void disableJvmtiEventClassLoad(void* thread);
extern void disableJvmtiEventClassPrepare(void* thread);
extern void disableJvmtiEventCompiledMethodLoad(void* thread);
extern void disableJvmtiEventCompiledMethodUnload(void* thread);
extern void disableJvmtiEventDataDumpRequest(void* thread);
extern void disableJvmtiEventDynamicCodeGenerated(void* thread);
extern void disableJvmtiEventException(void* thread);
extern void disableJvmtiEventExceptionCatch(void* thread);
extern void disableJvmtiEventFieldAccess(void* thread);
extern void disableJvmtiEventFieldModification(void* thread);
extern void disableJvmtiEventFramePop(void* thread);
extern void disableJvmtiEventGarbageCollectionFinish(void* thread);
extern void disableJvmtiEventGarbageCollectionStart(void* thread);
extern void disableJvmtiEventMethodEntry(void* thread);
extern void disableJvmtiEventMethodExit(void* thread);
extern void disableJvmtiEventMonitorContendedEnter(void* thread);
extern void disableJvmtiEventMonitorContendedEntered(void* thread);
extern void disableJvmtiEventMonitorWait(void* thread);
extern void disableJvmtiEventMonitorWaited(void* thread);
extern void disableJvmtiEventNativeMethodBind(void* thread);
extern void disableJvmtiEventObjectFree(void* thread);
extern void disableJvmtiEventResourceExhausted(void* thread);
extern void disableJvmtiEventSingleStep(void* thread);
extern void disableJvmtiEventThreadEnd(void* thread);
extern void disableJvmtiEventThreadStart(void* thread);
extern void disableJvmtiEventVmDeath(void* thread);
extern void disableJvmtiEventVmInit(void* thread);
extern void disableJvmtiEventVmObjectAlloc(void* thread);
extern void disableJvmtiEventVmStart(void* thread);
extern drill_agent_kref_com_epam_drill_plugin_DrillRequest drillRequest();
extern void enableJvmtiEventBreakpoint(void* thread);
extern void enableJvmtiEventClassFileLoadHook(void* thread);
extern void enableJvmtiEventClassLoad(void* thread);
extern void enableJvmtiEventClassPrepare(void* thread);
extern void enableJvmtiEventCompiledMethodLoad(void* thread);
extern void enableJvmtiEventCompiledMethodUnload(void* thread);
extern void enableJvmtiEventDataDumpRequest(void* thread);
extern void enableJvmtiEventDynamicCodeGenerated(void* thread);
extern void enableJvmtiEventException(void* thread);
extern void enableJvmtiEventExceptionCatch(void* thread);
extern void enableJvmtiEventFieldAccess(void* thread);
extern void enableJvmtiEventFieldModification(void* thread);
extern void enableJvmtiEventFramePop(void* thread);
extern void enableJvmtiEventGarbageCollectionFinish(void* thread);
extern void enableJvmtiEventGarbageCollectionStart(void* thread);
extern void enableJvmtiEventMethodEntry(void* thread);
extern void enableJvmtiEventMethodExit(void* thread);
extern void enableJvmtiEventMonitorContendedEnter(void* thread);
extern void enableJvmtiEventMonitorContendedEntered(void* thread);
extern void enableJvmtiEventMonitorWait(void* thread);
extern void enableJvmtiEventMonitorWaited(void* thread);
extern void enableJvmtiEventNativeMethodBind(void* thread);
extern void enableJvmtiEventObjectFree(void* thread);
extern void enableJvmtiEventResourceExhausted(void* thread);
extern void enableJvmtiEventSingleStep(void* thread);
extern void enableJvmtiEventThreadEnd(void* thread);
extern void enableJvmtiEventThreadStart(void* thread);
extern void enableJvmtiEventVmDeath(void* thread);
extern void enableJvmtiEventVmInit(void* thread);
extern void enableJvmtiEventVmObjectAlloc(void* thread);
extern void enableJvmtiEventVmStart(void* thread);
extern drill_agent_kref_com_epam_drill_plugin_api_processing_NativePart getPlugin(void* id);
extern void* jvmtix();
extern void SetEventCallbacksP(drill_agent_kref_kotlinx_cinterop_CValuesRef callbacks, drill_agent_KInt size_of_callbacks);
extern void* jvmtiCallbacks();
extern void sendToSocket(const char* pluginId, const char* message);
extern void* Java_com_epam_drill_session_DrillRequest_GetAllLoadedClasses(void* env, void* thiz);
extern drill_agent_KUInt Java_com_epam_drill_session_DrillRequest_RetransformClasses(void* env, void* thiz, drill_agent_KInt count, void* classes);
extern drill_agent_KInt Agent_OnLoad(void* vmPointer, const char* options, drill_agent_KLong reservedPtr);
extern void Agent_OnUnload(void* vmPointer);
extern drill_agent_KUInt checkEx(drill_agent_KUInt errCode, const char* funName);
extern void* currentEnvs();
extern void* Java_com_epam_drill_session_DrillRequest_currentSession(void* env, void* thiz);
extern void* Java_com_epam_drill_session_DrillRequest_get(void* env, void* thiz, void* key);
extern void* jvmtii();
extern void Java_com_epam_drill_plugin_api_processing_Sender_sendMessage(void* env, void* thiz, void* pluginId, void* message);
extern void jvmtiEventClassFileLoadHookEvent(void* jvmtiEnv, void* jniEnv, void* classBeingRedefined, void* loader, const char* kClassName, void* protection_domain, drill_agent_KInt classDataLen, void* classData, void* newClassDataLen, void* newData);
extern void jvmtiEventVMInitEvent(void* env, void* jniEnv, void* thread);

typedef struct {
  /* Service functions. */
  void (*DisposeStablePointer)(drill_agent_KNativePtr ptr);
  void (*DisposeString)(const char* string);
  drill_agent_KBoolean (*IsInstance)(drill_agent_KNativePtr ref, const drill_agent_KType* type);
  drill_agent_kref_kotlin_Byte (*createNullableByte)(drill_agent_KByte);
  drill_agent_kref_kotlin_Short (*createNullableShort)(drill_agent_KShort);
  drill_agent_kref_kotlin_Int (*createNullableInt)(drill_agent_KInt);
  drill_agent_kref_kotlin_Long (*createNullableLong)(drill_agent_KLong);
  drill_agent_kref_kotlin_Float (*createNullableFloat)(drill_agent_KFloat);
  drill_agent_kref_kotlin_Double (*createNullableDouble)(drill_agent_KDouble);
  drill_agent_kref_kotlin_Char (*createNullableChar)(drill_agent_KChar);
  drill_agent_kref_kotlin_Boolean (*createNullableBoolean)(drill_agent_KBoolean);
  drill_agent_kref_kotlin_Unit (*createNullableUnit)(void);

  /* User functions. */
  struct {
    struct {
      struct {
        struct {
          struct {
            drill_agent_kref_com_epam_drill_common_AgentType (*get_AGENT_TYPE)();
            struct {
              drill_agent_KType* (*_type)(void);
              drill_agent_kref_com_epam_drill_AgentPluginData (*_instance)();
              drill_agent_kref_kotlin_collections_Map (*get_classMap)(drill_agent_kref_com_epam_drill_AgentPluginData thiz);
              void (*set_classMap)(drill_agent_kref_com_epam_drill_AgentPluginData thiz, drill_agent_kref_kotlin_collections_Map set);
            } AgentPluginData;
            struct {
              void* (*JNIEn_)();
              void* (*JNIFun_)();
              void (*addPluginToRegistry_)(drill_agent_kref_com_epam_drill_plugin_api_processing_NativePart plugin);
              void* (*currentThread_)();
              void (*disableJvmtiEventBreakpoint_)(void* thread);
              void (*disableJvmtiEventClassFileLoadHook_)(void* thread);
              void (*disableJvmtiEventClassLoad_)(void* thread);
              void (*disableJvmtiEventClassPrepare_)(void* thread);
              void (*disableJvmtiEventCompiledMethodLoad_)(void* thread);
              void (*disableJvmtiEventCompiledMethodUnload_)(void* thread);
              void (*disableJvmtiEventDataDumpRequest_)(void* thread);
              void (*disableJvmtiEventDynamicCodeGenerated_)(void* thread);
              void (*disableJvmtiEventException_)(void* thread);
              void (*disableJvmtiEventExceptionCatch_)(void* thread);
              void (*disableJvmtiEventFieldAccess_)(void* thread);
              void (*disableJvmtiEventFieldModification_)(void* thread);
              void (*disableJvmtiEventFramePop_)(void* thread);
              void (*disableJvmtiEventGarbageCollectionFinish_)(void* thread);
              void (*disableJvmtiEventGarbageCollectionStart_)(void* thread);
              void (*disableJvmtiEventMethodEntry_)(void* thread);
              void (*disableJvmtiEventMethodExit_)(void* thread);
              void (*disableJvmtiEventMonitorContendedEnter_)(void* thread);
              void (*disableJvmtiEventMonitorContendedEntered_)(void* thread);
              void (*disableJvmtiEventMonitorWait_)(void* thread);
              void (*disableJvmtiEventMonitorWaited_)(void* thread);
              void (*disableJvmtiEventNativeMethodBind_)(void* thread);
              void (*disableJvmtiEventObjectFree_)(void* thread);
              void (*disableJvmtiEventResourceExhausted_)(void* thread);
              void (*disableJvmtiEventSingleStep_)(void* thread);
              void (*disableJvmtiEventThreadEnd_)(void* thread);
              void (*disableJvmtiEventThreadStart_)(void* thread);
              void (*disableJvmtiEventVmDeath_)(void* thread);
              void (*disableJvmtiEventVmInit_)(void* thread);
              void (*disableJvmtiEventVmObjectAlloc_)(void* thread);
              void (*disableJvmtiEventVmStart_)(void* thread);
              void* (*drillCRequest)(void* thread);
              drill_agent_kref_com_epam_drill_plugin_DrillRequest (*drillRequest_)();
              void (*enableJvmtiEventBreakpoint_)(void* thread);
              void (*enableJvmtiEventClassFileLoadHook_)(void* thread);
              void (*enableJvmtiEventClassLoad_)(void* thread);
              void (*enableJvmtiEventClassPrepare_)(void* thread);
              void (*enableJvmtiEventCompiledMethodLoad_)(void* thread);
              void (*enableJvmtiEventCompiledMethodUnload_)(void* thread);
              void (*enableJvmtiEventDataDumpRequest_)(void* thread);
              void (*enableJvmtiEventDynamicCodeGenerated_)(void* thread);
              void (*enableJvmtiEventException_)(void* thread);
              void (*enableJvmtiEventExceptionCatch_)(void* thread);
              void (*enableJvmtiEventFieldAccess_)(void* thread);
              void (*enableJvmtiEventFieldModification_)(void* thread);
              void (*enableJvmtiEventFramePop_)(void* thread);
              void (*enableJvmtiEventGarbageCollectionFinish_)(void* thread);
              void (*enableJvmtiEventGarbageCollectionStart_)(void* thread);
              void (*enableJvmtiEventMethodEntry_)(void* thread);
              void (*enableJvmtiEventMethodExit_)(void* thread);
              void (*enableJvmtiEventMonitorContendedEnter_)(void* thread);
              void (*enableJvmtiEventMonitorContendedEntered_)(void* thread);
              void (*enableJvmtiEventMonitorWait_)(void* thread);
              void (*enableJvmtiEventMonitorWaited_)(void* thread);
              void (*enableJvmtiEventNativeMethodBind_)(void* thread);
              void (*enableJvmtiEventObjectFree_)(void* thread);
              void (*enableJvmtiEventResourceExhausted_)(void* thread);
              void (*enableJvmtiEventSingleStep_)(void* thread);
              void (*enableJvmtiEventThreadEnd_)(void* thread);
              void (*enableJvmtiEventThreadStart_)(void* thread);
              void (*enableJvmtiEventVmDeath_)(void* thread);
              void (*enableJvmtiEventVmInit_)(void* thread);
              void (*enableJvmtiEventVmObjectAlloc_)(void* thread);
              void (*enableJvmtiEventVmStart_)(void* thread);
              drill_agent_kref_com_epam_drill_plugin_api_processing_NativePart (*getPlugin_)(void* id);
              void* (*jvmti)();
              void (*jvmti_)(drill_agent_kref_kotlinx_cinterop_CValuesRef callbacks, drill_agent_KInt size_of_callbacks);
              void* (*jvmtiCallback)();
              void (*sendToSocket_)(const char* pluginId, const char* message);
            } api;
            struct {
              const char* (*get_drillInstallationDir)();
              drill_agent_kref_com_epam_drill_core_DI (*get_dsa)();
              drill_agent_KInt (*get_work)();
              void* (*GetAllLoadedClasses)(void* env, void* thiz);
              drill_agent_KUInt (*RetransformClasses)(void* env, void* thiz, drill_agent_KInt count, void* classes);
              drill_agent_KInt (*agentOnLoad)(void* vmPointer, const char* options, drill_agent_KLong reservedPtr);
              void (*agentOnUnload)(void* vmPointer);
              drill_agent_KUInt (*checkEx_)(drill_agent_KUInt errCode, const char* funName);
              void* (*currentEnvs_)();
              void* (*currentsession4java)(void* env, void* thiz);
              void* (*getHeader4java)(void* env, void* thiz, void* key);
              void* (*jvmtii_)();
              void (*sendFromJava)(void* env, void* thiz, void* pluginId, void* message);
              void (*vmDeathEvent)(void* jvmtiEnv, void* jniEnv);
              drill_agent_kref_kotlin_collections_Map (*asAgentParams)(const char* thiz);
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_core_DI (*DI)();
                drill_agent_kref_com_epam_drill_common_ws_URL (*get_adminAddress)(drill_agent_kref_com_epam_drill_core_DI thiz);
                void (*set_adminAddress)(drill_agent_kref_com_epam_drill_core_DI thiz, drill_agent_kref_com_epam_drill_common_ws_URL set);
                drill_agent_kref_com_epam_drill_common_AgentConfig (*get_agentConfig)(drill_agent_kref_com_epam_drill_core_DI thiz);
                void (*set_agentConfig)(drill_agent_kref_com_epam_drill_core_DI thiz, drill_agent_kref_com_epam_drill_common_AgentConfig set);
                const char* (*get_drillInstallationDir)(drill_agent_kref_com_epam_drill_core_DI thiz);
                void (*set_drillInstallationDir)(drill_agent_kref_com_epam_drill_core_DI thiz, const char* set);
                drill_agent_kref_kotlin_collections_MutableMap (*get_pl)(drill_agent_kref_com_epam_drill_core_DI thiz);
                drill_agent_kref_kotlin_collections_MutableMap (*get_pstorage)(drill_agent_kref_com_epam_drill_core_DI thiz);
                void (*set_pstorage)(drill_agent_kref_com_epam_drill_core_DI thiz, drill_agent_kref_kotlin_collections_MutableMap set);
                const char* (*get_requestPattern)(drill_agent_kref_com_epam_drill_core_DI thiz);
                void (*set_requestPattern)(drill_agent_kref_com_epam_drill_core_DI thiz, const char* set);
                drill_agent_kref_com_epam_drill_common_ws_URL (*get_secureAdminAddress)(drill_agent_kref_com_epam_drill_core_DI thiz);
                void (*set_secureAdminAddress)(drill_agent_kref_com_epam_drill_core_DI thiz, drill_agent_kref_com_epam_drill_common_ws_URL set);
              } DI;
              struct {
                void (*calculateBuildVersion)();
                drill_agent_kref_kotlin_collections_List (*getClassesByConfig)();
                drill_agent_kref_kotlin_collections_List (*getProcessInfo)(drill_agent_KInt bufferSize);
                drill_agent_kref_com_epam_drill_core_agent_JavaProcess (*javaProcess)();
                void (*performAgentInitialization)(drill_agent_kref_kotlin_collections_Map initialParams);
                void (*setPackagesPrefixes)(const char* prefixes);
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_agent_Gaps (*Gaps)(drill_agent_KBoolean interrupted, drill_agent_KBoolean spacedString);
                  drill_agent_KBoolean (*get_interrupted)(drill_agent_kref_com_epam_drill_core_agent_Gaps thiz);
                  void (*set_interrupted)(drill_agent_kref_com_epam_drill_core_agent_Gaps thiz, drill_agent_KBoolean set);
                  drill_agent_KBoolean (*get_spacedString)(drill_agent_kref_com_epam_drill_core_agent_Gaps thiz);
                  void (*set_spacedString)(drill_agent_kref_com_epam_drill_core_agent_Gaps thiz, drill_agent_KBoolean set);
                } Gaps;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_agent_JavaProcess (*JavaProcess)(drill_agent_kref_kotlin_collections_MutableList javaAgents, drill_agent_kref_kotlin_collections_MutableList nativeAgents, const char* processPath, const char* classpath, const char* jar, drill_agent_kref_kotlin_collections_List javaParams);
                  const char* (*get_classpath)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz);
                  void (*set_classpath)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz, const char* set);
                  const char* (*get_firstAgentPath)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz);
                  const char* (*get_jar)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz);
                  void (*set_jar)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz, const char* set);
                  drill_agent_kref_kotlin_collections_MutableList (*get_javaAgents)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz);
                  drill_agent_kref_kotlin_collections_List (*get_javaParams)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz);
                  void (*set_javaParams)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz, drill_agent_kref_kotlin_collections_List set);
                  drill_agent_kref_kotlin_collections_MutableList (*get_nativeAgents)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz);
                  const char* (*get_processPath)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz);
                  void (*set_processPath)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz, const char* set);
                  drill_agent_kref_kotlin_collections_MutableList (*component1)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz);
                  drill_agent_kref_kotlin_collections_MutableList (*component2)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz);
                  const char* (*component3)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz);
                  const char* (*component4)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz);
                  const char* (*component5)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz);
                  drill_agent_kref_kotlin_collections_List (*component6)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz);
                  drill_agent_kref_com_epam_drill_core_agent_JavaProcess (*copy)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz, drill_agent_kref_kotlin_collections_MutableList javaAgents, drill_agent_kref_kotlin_collections_MutableList nativeAgents, const char* processPath, const char* classpath, const char* jar, drill_agent_kref_kotlin_collections_List javaParams);
                  drill_agent_KBoolean (*equals)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz, drill_agent_kref_kotlin_Any other);
                  drill_agent_KInt (*hashCode)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz);
                  const char* (*toString)(drill_agent_kref_com_epam_drill_core_agent_JavaProcess thiz);
                } JavaProcess;
              } agent;
              struct {
                struct {
                  void (*classLoadEvent)(void* jvmtiEnv, void* jniEnv, void* classBeingRedefined, void* loader, const char* kClassName, void* protection_domain, drill_agent_KInt classDataLen, void* classData, void* newClassDataLen, void* newData);
                } classloading;
                struct {
                  drill_agent_KInt (*get_wsThread)();
                  void (*jvmtiEventVMInitEvent_)(void* env, void* jniEnv, void* thread);
                } vminit;
              } callbacks;
              struct {
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_concurrency_BackgroundThread (*_instance)();
                  drill_agent_kref_kotlin_coroutines_CoroutineContext (*get_coroutineContext)(drill_agent_kref_com_epam_drill_core_concurrency_BackgroundThread thiz);
                  drill_agent_kref_kotlinx_coroutines_Job (*invoke)(drill_agent_kref_com_epam_drill_core_concurrency_BackgroundThread thiz, drill_agent_kref_kotlin_coroutines_SuspendFunction0 block);
                } BackgroundThread;
              } concurrency;
              struct {
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_exceptions_PluginLoadException (*PluginLoadException)(const char* message);
                } PluginLoadException;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_exceptions_WsClosedException (*WsClosedException)(const char* message);
                } WsClosedException;
              } exceptions;
              struct {
                void (*sendMessage)(const char* pluginId, const char* content);
                void (*sendNativeMessage)(void* pluginId, void* content);
              } messanger;
              struct {
                drill_agent_kref_mu_KLogger (*get_httpRequestLogger)();
                void (*configureHttp)();
                void (*fillRequestToHolder)(const char* request);
                const char* (*sessionId)();
              } methodbind;
              struct {
                drill_agent_kref_com_epam_drill_common_PluginMetadata (*pluginConfigById)(const char* pluginId);
                drill_agent_kref_kotlin_collections_MutableMap (*get_storage)();
                drill_agent_kref_com_epam_drill_common_PluginMetadata (*actualPluginConfig)(drill_agent_kref_com_epam_drill_plugin_api_processing_AgentPart thiz);
                struct {
                  struct {
                    drill_agent_KType* (*_type)(void);
                    drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage (*DrillMessage)(drill_agent_KInt seen1, const char* sessionId, const char* content, drill_agent_kref_kotlinx_serialization_SerializationConstructorMarker serializationConstructorMarker);
                    drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage (*DrillMessage_)(const char* sessionId, const char* content);
                    const char* (*get_content)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz);
                    void (*set_content)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz, const char* set);
                    const char* (*get_sessionId)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz);
                    void (*set_sessionId)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz, const char* set);
                    const char* (*component1)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz);
                    const char* (*component2)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz);
                    drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage (*copy)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz, const char* sessionId, const char* content);
                    drill_agent_KBoolean (*equals)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz, drill_agent_kref_kotlin_Any other);
                    drill_agent_KInt (*hashCode)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz);
                    const char* (*toString)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz);
                    struct {
                      drill_agent_KType* (*_type)(void);
                      drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_$serializer (*_instance)();
                      drill_agent_kref_kotlinx_serialization_SerialDescriptor (*get_descriptor)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_$serializer thiz);
                      drill_agent_kref_kotlin_Array (*childSerializers)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_$serializer thiz);
                      drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage (*deserialize)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_$serializer thiz, drill_agent_kref_kotlinx_serialization_Decoder decoder);
                      void (*serialize)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_$serializer thiz, drill_agent_kref_kotlinx_serialization_Encoder encoder, drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage obj);
                    } $serializer;
                    struct {
                      drill_agent_KType* (*_type)(void);
                      drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_Companion (*_instance)();
                      drill_agent_kref_kotlinx_serialization_KSerializer (*serializer)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_Companion thiz);
                    } Companion;
                  } DrillMessage;
                  struct {
                    drill_agent_KType* (*_type)(void);
                    drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper (*MessageWrapper)(drill_agent_KInt seen1, const char* pluginId, drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage drillMessage, drill_agent_kref_kotlinx_serialization_SerializationConstructorMarker serializationConstructorMarker);
                    drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper (*MessageWrapper_)(const char* pluginId, drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage drillMessage);
                    drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage (*get_drillMessage)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper thiz);
                    void (*set_drillMessage)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper thiz, drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage set);
                    const char* (*get_pluginId)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper thiz);
                    void (*set_pluginId)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper thiz, const char* set);
                    struct {
                      drill_agent_KType* (*_type)(void);
                      drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_$serializer (*_instance)();
                      drill_agent_kref_kotlinx_serialization_SerialDescriptor (*get_descriptor)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_$serializer thiz);
                      drill_agent_kref_kotlin_Array (*childSerializers)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_$serializer thiz);
                      drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper (*deserialize)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_$serializer thiz, drill_agent_kref_kotlinx_serialization_Decoder decoder);
                      void (*serialize)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_$serializer thiz, drill_agent_kref_kotlinx_serialization_Encoder encoder, drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper obj);
                    } $serializer;
                    struct {
                      drill_agent_KType* (*_type)(void);
                      drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_Companion (*_instance)();
                      drill_agent_kref_kotlinx_serialization_KSerializer (*serializer)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_Companion thiz);
                    } Companion;
                  } MessageWrapper;
                } dto;
                struct {
                  drill_agent_kref_mu_KLogger (*get_plLogger)();
                  void (*loadPlugin)(const char* pluginFilePath, drill_agent_kref_com_epam_drill_common_PluginMetadata pluginConfig);
                  struct {
                    drill_agent_KType* (*_type)(void);
                    drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin (*GenericNativePlugin)(const char* pluginId, void* pluginApiClass, void* userPlugin, drill_agent_kref_com_epam_drill_common_PluginMetadata pluginConfig);
                    const char* (*get_id)(drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin thiz);
                    void* (*get_pluginApiClass)(drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin thiz);
                    void* (*get_userPlugin)(drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin thiz);
                    void (*load)(drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin thiz, drill_agent_KBoolean onImmediately);
                    void (*off)(drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin thiz);
                    void (*on)(drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin thiz);
                    void (*unload)(drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin thiz, drill_agent_kref_com_epam_drill_plugin_api_processing_UnloadReason unloadReason);
                    void (*updateRawConfig)(drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin thiz, drill_agent_kref_com_epam_drill_common_PluginConfig config);
                  } GenericNativePlugin;
                  struct {
                    drill_agent_KType* (*_type)(void);
                    drill_agent_kref_com_epam_drill_core_plugin_loader_InstrumentationNativePlugin (*InstrumentationNativePlugin)(const char* pluginId, void* pluginApiClass, void* userPlugin, drill_agent_kref_com_epam_drill_common_PluginMetadata pluginConfig, void* qs);
                    drill_agent_kref_kotlin_ByteArray (*instrument)(drill_agent_kref_com_epam_drill_core_plugin_loader_InstrumentationNativePlugin thiz, const char* className, drill_agent_kref_kotlin_ByteArray initialBytes);
                    void (*retransform)(drill_agent_kref_com_epam_drill_core_plugin_loader_InstrumentationNativePlugin thiz);
                  } InstrumentationNativePlugin;
                } loader;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_plugin_PluginManager (*_instance)();
                  void (*addPlugin)(drill_agent_kref_com_epam_drill_plugin_PluginManager thiz, drill_agent_kref_com_epam_drill_plugin_api_processing_AgentPart plugin);
                  drill_agent_kref_kotlin_collections_List (*get)(drill_agent_kref_com_epam_drill_plugin_PluginManager thiz, drill_agent_kref_com_epam_drill_common_Family id);
                  drill_agent_kref_com_epam_drill_plugin_api_processing_AgentPart (*get_)(drill_agent_kref_com_epam_drill_plugin_PluginManager thiz, const char* id);
                } PluginManager;
              } plugin;
              struct {
                drill_agent_KLong (*get_DELAY)();
                drill_agent_kref_kotlinx_coroutines_channels_Channel (*get_msChannel)();
                void (*arraycopy)(drill_agent_kref_kotlin_ByteArray src, drill_agent_KInt srcPos, drill_agent_kref_kotlin_ByteArray dst, drill_agent_KInt dstPos, drill_agent_KInt size);
                drill_agent_kref_kotlinx_coroutines_Deferred (*asyncImmediately)(drill_agent_kref_kotlin_coroutines_CoroutineContext context, drill_agent_kref_kotlin_coroutines_SuspendFunction0 callback);
                void (*topicRegister)();
                drill_agent_kref_kotlinx_coroutines_Deferred (*asyncImmediately_)(drill_agent_kref_kotlinx_coroutines_CoroutineScope thiz, drill_agent_kref_kotlin_coroutines_SuspendFunction0 callback);
                drill_agent_kref_com_epam_drill_core_ws_AsyncStream (*openAsync)(drill_agent_kref_kotlin_ByteArray thiz);
                drill_agent_kref_com_epam_drill_core_ws_AsyncStream (*toAsyncStream)(drill_agent_kref_com_epam_drill_core_ws_AsyncStreamBase thiz, drill_agent_KLong position);
                const char* (*toHexString)(drill_agent_kref_kotlin_ByteArray thiz);
                drill_agent_kref_com_epam_drill_core_ws_WsRouter_inners (*topic)(drill_agent_kref_com_epam_drill_core_ws_WsRouter thiz);
                void (*topic_)(drill_agent_kref_com_epam_drill_core_ws_WsRouter thiz, drill_agent_kref_kotlin_coroutines_SuspendFunction1 block);
                void (*topic__)(drill_agent_kref_com_epam_drill_core_ws_WsRouter thiz, drill_agent_kref_kotlin_coroutines_SuspendFunction1 block);
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncBaseStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                  struct {
                    drill_agent_KType* (*_type)(void);
                    drill_agent_kref_com_epam_drill_core_ws_AsyncCloseable_Companion (*_instance)();
                  } Companion;
                } AsyncCloseable;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncGetLengthStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncGetPositionStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncInputStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncInputStreamWithLength;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncInvokable;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncLengthStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncOutputStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncPositionLengthStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncPositionStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncRAInputStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncRAOutputStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_AsyncStream (*AsyncStream)(drill_agent_kref_com_epam_drill_core_ws_AsyncStreamBase base, drill_agent_KLong position);
                  drill_agent_kref_com_epam_drill_core_ws_AsyncStreamBase (*get_base)(drill_agent_kref_com_epam_drill_core_ws_AsyncStream thiz);
                  drill_agent_KLong (*get_position)(drill_agent_kref_com_epam_drill_core_ws_AsyncStream thiz);
                  void (*set_position)(drill_agent_kref_com_epam_drill_core_ws_AsyncStream thiz, drill_agent_KLong set);
                } AsyncStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_AsyncStreamBase (*AsyncStreamBase)();
                } AsyncStreamBase;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_AsyncThread (*AsyncThread)();
                  drill_agent_kref_kotlinx_coroutines_Deferred (*sync)(drill_agent_kref_com_epam_drill_core_ws_AsyncThread thiz, drill_agent_kref_kotlin_coroutines_CoroutineContext context, drill_agent_kref_kotlin_coroutines_SuspendFunction0 func);
                } AsyncThread;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_InfoTopic (*InfoTopic)(const char* destination, drill_agent_kref_kotlin_coroutines_SuspendFunction1 block);
                  drill_agent_kref_kotlin_coroutines_SuspendFunction1 (*get_block)(drill_agent_kref_com_epam_drill_core_ws_InfoTopic thiz);
                  const char* (*get_destination)(drill_agent_kref_com_epam_drill_core_ws_InfoTopic thiz);
                } InfoTopic;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_MemoryAsyncStreamBase (*MemoryAsyncStreamBase)(drill_agent_kref_kotlin_ByteArray data);
                  drill_agent_kref_kotlin_ByteArray (*get_data)(drill_agent_kref_com_epam_drill_core_ws_MemoryAsyncStreamBase thiz);
                  void (*set_data)(drill_agent_kref_com_epam_drill_core_ws_MemoryAsyncStreamBase thiz, drill_agent_kref_kotlin_ByteArray set);
                  drill_agent_KInt (*get_ilength)(drill_agent_kref_com_epam_drill_core_ws_MemoryAsyncStreamBase thiz);
                  void (*set_ilength)(drill_agent_kref_com_epam_drill_core_ws_MemoryAsyncStreamBase thiz, drill_agent_KInt set);
                  void (*checkPosition)(drill_agent_kref_com_epam_drill_core_ws_MemoryAsyncStreamBase thiz, drill_agent_KLong position);
                  const char* (*toString)(drill_agent_kref_com_epam_drill_core_ws_MemoryAsyncStreamBase thiz);
                } MemoryAsyncStreamBase;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_PluginTopic (*PluginTopic)(const char* destination, drill_agent_kref_kotlin_coroutines_SuspendFunction2 block);
                  drill_agent_kref_kotlin_coroutines_SuspendFunction2 (*get_block)(drill_agent_kref_com_epam_drill_core_ws_PluginTopic thiz);
                  const char* (*get_destination)(drill_agent_kref_com_epam_drill_core_ws_PluginTopic thiz);
                } PluginTopic;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_Sender (*_instance)();
                  drill_agent_kref_kotlin_coroutines_CoroutineContext (*get_coroutineContext)(drill_agent_kref_com_epam_drill_core_ws_Sender thiz);
                  drill_agent_kref_kotlinx_coroutines_Job (*invoke)(drill_agent_kref_com_epam_drill_core_ws_Sender thiz, drill_agent_kref_kotlin_coroutines_SuspendFunction0 block);
                } Sender;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_Topic (*Topic)(const char* destination);
                  const char* (*get_destination)(drill_agent_kref_com_epam_drill_core_ws_Topic thiz);
                } Topic;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_WsRouter (*_instance)();
                  drill_agent_kref_kotlin_collections_MutableMap (*get_mapper)(drill_agent_kref_com_epam_drill_core_ws_WsRouter thiz);
                  drill_agent_kref_com_epam_drill_core_ws_Topic (*get)(drill_agent_kref_com_epam_drill_core_ws_WsRouter thiz, const char* topic);
                  void (*invoke)(drill_agent_kref_com_epam_drill_core_ws_WsRouter thiz, drill_agent_kref_kotlin_Function1 alotoftopics);
                  struct {
                    drill_agent_KType* (*_type)(void);
                    drill_agent_kref_com_epam_drill_core_ws_WsRouter_inners (*inners)(const char* destination);
                    const char* (*get_destination)(drill_agent_kref_com_epam_drill_core_ws_WsRouter_inners thiz);
                    drill_agent_kref_com_epam_drill_core_ws_PluginTopic (*withPluginTopic)(drill_agent_kref_com_epam_drill_core_ws_WsRouter_inners thiz, drill_agent_kref_kotlin_coroutines_SuspendFunction2 block);
                  } inners;
                } WsRouter;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_WsSocket (*WsSocket)();
                  drill_agent_kref_kotlin_coroutines_CoroutineContext (*get_coroutineContext)(drill_agent_kref_com_epam_drill_core_ws_WsSocket thiz);
                  void (*close)(drill_agent_kref_com_epam_drill_core_ws_WsSocket thiz);
                  drill_agent_kref_kotlinx_coroutines_Job (*connect)(drill_agent_kref_com_epam_drill_core_ws_WsSocket thiz, const char* adminUrl);
                } WsSocket;
              } ws;
            } core;
            struct {
              drill_agent_kref_kotlin_ByteArray (*hash)(drill_agent_kref_kotlin_ByteArray thiz, drill_agent_kref_com_epam_drill_crypto_HashFactory algo);
              drill_agent_kref_kotlin_ByteArray (*md5)(drill_agent_kref_kotlin_ByteArray thiz);
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_crypto_Hash (*Hash)(drill_agent_KInt chunkSize, drill_agent_KInt digestSize);
                drill_agent_KInt (*get_chunkSize)(drill_agent_kref_com_epam_drill_crypto_Hash thiz);
                drill_agent_KInt (*get_digestSize)(drill_agent_kref_com_epam_drill_crypto_Hash thiz);
                void (*coreDigest)(drill_agent_kref_com_epam_drill_crypto_Hash thiz, drill_agent_kref_kotlin_ByteArray out);
                drill_agent_kref_kotlin_ByteArray (*corePadding)(drill_agent_kref_com_epam_drill_crypto_Hash thiz, drill_agent_KLong totalWritten);
                void (*coreReset)(drill_agent_kref_com_epam_drill_crypto_Hash thiz);
                void (*coreUpdate)(drill_agent_kref_com_epam_drill_crypto_Hash thiz, drill_agent_kref_kotlin_ByteArray chunk);
                drill_agent_kref_kotlin_ByteArray (*digest)(drill_agent_kref_com_epam_drill_crypto_Hash thiz);
                void (*digestOut)(drill_agent_kref_com_epam_drill_crypto_Hash thiz, drill_agent_kref_kotlin_ByteArray out);
                drill_agent_kref_com_epam_drill_crypto_Hash (*reset)(drill_agent_kref_com_epam_drill_crypto_Hash thiz);
                drill_agent_kref_com_epam_drill_crypto_Hash (*update)(drill_agent_kref_com_epam_drill_crypto_Hash thiz, drill_agent_kref_kotlin_ByteArray data);
                drill_agent_kref_com_epam_drill_crypto_Hash (*update_)(drill_agent_kref_com_epam_drill_crypto_Hash thiz, drill_agent_kref_kotlin_ByteArray data, drill_agent_KInt offset, drill_agent_KInt count);
              } Hash;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_crypto_HashFactory (*HashFactory)(drill_agent_kref_kotlin_Function0 create);
                drill_agent_kref_kotlin_Function0 (*get_create)(drill_agent_kref_com_epam_drill_crypto_HashFactory thiz);
                drill_agent_kref_kotlin_ByteArray (*digest)(drill_agent_kref_com_epam_drill_crypto_HashFactory thiz, drill_agent_kref_kotlin_ByteArray data);
              } HashFactory;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_crypto_MD5 (*MD5)();
                void (*coreDigest)(drill_agent_kref_com_epam_drill_crypto_MD5 thiz, drill_agent_kref_kotlin_ByteArray out);
                drill_agent_kref_kotlin_ByteArray (*corePadding)(drill_agent_kref_com_epam_drill_crypto_MD5 thiz, drill_agent_KLong totalWritten);
                void (*coreReset)(drill_agent_kref_com_epam_drill_crypto_MD5 thiz);
                void (*coreUpdate)(drill_agent_kref_com_epam_drill_crypto_MD5 thiz, drill_agent_kref_kotlin_ByteArray chunk);
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_crypto_MD5_Companion (*_instance)();
                } Companion;
              } MD5;
            } crypto;
          } drill;
        } epam;
      } com;
    } root;
  } kotlin;
} drill_agent_ExportedSymbols;
extern drill_agent_ExportedSymbols* drill_agent_symbols(void);
#ifdef __cplusplus
}  /* extern "C" */
#endif
#endif  /* KONAN_DRILL_AGENT_H */
