#ifndef KONAN_DRILL_AGENT_H
#define KONAN_DRILL_AGENT_H
#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
typedef bool            drill_agent_KBoolean;
#else
typedef _Bool           drill_agent_KBoolean;
#endif
typedef unsigned short     drill_agent_KChar;
typedef signed char        drill_agent_KByte;
typedef short              drill_agent_KShort;
typedef int                drill_agent_KInt;
typedef long long          drill_agent_KLong;
typedef unsigned char      drill_agent_KUByte;
typedef unsigned short     drill_agent_KUShort;
typedef unsigned int       drill_agent_KUInt;
typedef unsigned long long drill_agent_KULong;
typedef float              drill_agent_KFloat;
typedef double             drill_agent_KDouble;
typedef void*              drill_agent_KNativePtr;
struct drill_agent_KType;
typedef struct drill_agent_KType drill_agent_KType;

typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Byte;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Short;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Int;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Long;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Float;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Double;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Char;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Boolean;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Unit;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_MemBuffer;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_Int8Buffer;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_Int16Buffer;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_Int32Buffer;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_Float32Buffer;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_Float64Buffer;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_ByteArray;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_ByteArrayBuilder;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_IntArray;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_AgentPluginData;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_collections_Map;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_Int8Buffer_Companion;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_Int16Buffer_Companion;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_Int32Buffer_Companion;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_Float32Buffer_Companion;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_Float64Buffer_Companion;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_plugin_DrillRequest;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_cinterop_CValuesRef;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_plugin_api_processing_NativePart;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_collections_ArrayList;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Function1;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_async_Signal;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_DI;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_common_ws_URL;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_common_AgentConfig;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_collections_MutableMap;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_DI_NativeMethodBinder;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Any;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_reflect_KFunction2;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_reflect_KFunction3;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_reflect_KFunction4;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_reflect_KFunction5;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_reflect_KFunction6;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_collections_List;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Function2;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_concurrency_Symbol;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_exceptions_PluginLoadException;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_exceptions_WsClosedException;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_common_PluginMetadata;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_plugin_api_processing_AgentPart;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_serialization_SerializationConstructorMarker;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_Companion;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_serialization_KSerializer;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_$serializer;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_serialization_SerialDescriptor;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Array;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_serialization_Decoder;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_serialization_Encoder;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_Companion;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_$serializer;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_logger_DLogger;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_plugin_api_processing_UnloadReason;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_common_PluginConfig;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_plugin_loader_InstrumentationNativePlugin;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_plugin_PluginManager;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_common_Family;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncStreamBase;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_coroutines_CoroutineContext;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_coroutines_SuspendFunction0;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_coroutines_Deferred;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlinx_coroutines_CoroutineScope;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_WsRouter;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_WsRouter_inners;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_coroutines_SuspendFunction1;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_MemoryAsyncStreamBase;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncOutputStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncBaseStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncCloseable;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncCloseable_Companion;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncInputStreamWithLength;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncGetPositionStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncPositionLengthStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncPositionStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncInvokable;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncThread;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncRAInputStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncRAOutputStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncInputStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncLengthStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_AsyncGetLengthStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_Topic;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_GenericTopic;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_coroutines_SuspendFunction2;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_PluginTopic;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_core_ws_InfoTopic;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_ws_WsFrame;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_ws_WsFrame_Companion;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_ws_RawSocketWebSocketClient;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_net_AsyncClient;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_ws_WebSocketClient;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_collections_MutableSet;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_crypto_HashFactory;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_Function0;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_crypto_Hash;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_crypto_MD5;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_crypto_MD5_Companion;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_lang_Charset;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_CharSequence;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_text_StringBuilder;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_lang_UTC8CharsetBase;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_lang_IOException;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_lang_EOFException;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_lang_InvalidOperationException;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_io_ktor_util_date_GMTDate;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_net_AsyncSocketFactory;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_net_AsyncClient_Companion;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_net_NativeAsyncSocketFactory;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_net_NativeAsyncSocketFactory_NativeAsyncClient;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_net_NativeSocket;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_net_NativeSocket_Companion;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_AsyncInputStreamWithLength;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_SyncOutputStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_SyncStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_SyncStreamBase;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_AsyncCloseable;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_AsyncBaseStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_AsyncInputStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_AsyncOutputStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_AsyncGetPositionStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_AsyncGetLengthStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_Closeable;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_SyncInputStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_SyncPositionStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_SyncLengthStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_SyncRAInputStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_SyncRAOutputStream;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_Extra;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_kotlin_collections_HashMap;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_Extra_Mixin;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_stream_MemorySyncStreamBase;
typedef struct {
  drill_agent_KNativePtr pinned;
} drill_agent_kref_com_epam_drill_util_encoding_Base64;

extern void* JNIFun();
extern void* JNIEn();
extern void sendToSocket(const char* pluginId, const char* message);
extern void* currentThread();
extern drill_agent_kref_com_epam_drill_plugin_DrillRequest drillRequest();
extern void* jvmtix();
extern void SetEventCallbacksP(drill_agent_kref_kotlinx_cinterop_CValuesRef callbacks, drill_agent_KInt size_of_callbacks);
extern void* jvmtiCallbacks();
extern void enableJvmtiEventBreakpoint(void* thread);
extern void enableJvmtiEventClassFileLoadHook(void* thread);
extern void enableJvmtiEventClassLoad(void* thread);
extern void enableJvmtiEventClassPrepare(void* thread);
extern void enableJvmtiEventCompiledMethodLoad(void* thread);
extern void enableJvmtiEventCompiledMethodUnload(void* thread);
extern void enableJvmtiEventDataDumpRequest(void* thread);
extern void enableJvmtiEventDynamicCodeGenerated(void* thread);
extern void enableJvmtiEventException(void* thread);
extern void enableJvmtiEventExceptionCatch(void* thread);
extern void enableJvmtiEventFieldAccess(void* thread);
extern void enableJvmtiEventFieldModification(void* thread);
extern void enableJvmtiEventFramePop(void* thread);
extern void enableJvmtiEventGarbageCollectionFinish(void* thread);
extern void enableJvmtiEventGarbageCollectionStart(void* thread);
extern void enableJvmtiEventMethodEntry(void* thread);
extern void enableJvmtiEventMethodExit(void* thread);
extern void enableJvmtiEventMonitorContendedEnter(void* thread);
extern void enableJvmtiEventMonitorContendedEntered(void* thread);
extern void enableJvmtiEventMonitorWait(void* thread);
extern void enableJvmtiEventMonitorWaited(void* thread);
extern void enableJvmtiEventNativeMethodBind(void* thread);
extern void enableJvmtiEventObjectFree(void* thread);
extern void enableJvmtiEventResourceExhausted(void* thread);
extern void enableJvmtiEventSingleStep(void* thread);
extern void enableJvmtiEventThreadEnd(void* thread);
extern void enableJvmtiEventThreadStart(void* thread);
extern void enableJvmtiEventVmDeath(void* thread);
extern void enableJvmtiEventVmInit(void* thread);
extern void enableJvmtiEventVmObjectAlloc(void* thread);
extern void enableJvmtiEventVmStart(void* thread);
extern void disableJvmtiEventBreakpoint(void* thread);
extern void disableJvmtiEventClassFileLoadHook(void* thread);
extern void disableJvmtiEventClassLoad(void* thread);
extern void disableJvmtiEventClassPrepare(void* thread);
extern void disableJvmtiEventCompiledMethodLoad(void* thread);
extern void disableJvmtiEventCompiledMethodUnload(void* thread);
extern void disableJvmtiEventDataDumpRequest(void* thread);
extern void disableJvmtiEventDynamicCodeGenerated(void* thread);
extern void disableJvmtiEventException(void* thread);
extern void disableJvmtiEventExceptionCatch(void* thread);
extern void disableJvmtiEventFieldAccess(void* thread);
extern void disableJvmtiEventFieldModification(void* thread);
extern void disableJvmtiEventFramePop(void* thread);
extern void disableJvmtiEventGarbageCollectionFinish(void* thread);
extern void disableJvmtiEventGarbageCollectionStart(void* thread);
extern void disableJvmtiEventMethodEntry(void* thread);
extern void disableJvmtiEventMethodExit(void* thread);
extern void disableJvmtiEventMonitorContendedEnter(void* thread);
extern void disableJvmtiEventMonitorContendedEntered(void* thread);
extern void disableJvmtiEventMonitorWait(void* thread);
extern void disableJvmtiEventMonitorWaited(void* thread);
extern void disableJvmtiEventNativeMethodBind(void* thread);
extern void disableJvmtiEventObjectFree(void* thread);
extern void disableJvmtiEventResourceExhausted(void* thread);
extern void disableJvmtiEventSingleStep(void* thread);
extern void disableJvmtiEventThreadEnd(void* thread);
extern void disableJvmtiEventThreadStart(void* thread);
extern void disableJvmtiEventVmDeath(void* thread);
extern void disableJvmtiEventVmInit(void* thread);
extern void disableJvmtiEventVmObjectAlloc(void* thread);
extern void disableJvmtiEventVmStart(void* thread);
extern drill_agent_kref_com_epam_drill_plugin_api_processing_NativePart getPlugin(void* id);
extern void addPluginToRegistry(drill_agent_kref_com_epam_drill_plugin_api_processing_NativePart plugin);
extern drill_agent_KInt Agent_OnLoad(void* vmPointer, const char* options, drill_agent_KLong reservedPtr);
extern void Agent_OnUnload(void* vmPointer);
extern void* currentEnvs();
extern void* jvmtii();
extern drill_agent_KUInt checkEx(drill_agent_KUInt errCode, const char* funName);
extern void Java_com_epam_drill_plugin_api_processing_Sender_sendMessage(void* env, void* thiz, void* pluginId, void* message);
extern void* Java_com_epam_drill_session_DrillRequest_currentSession(void* env, void* thiz);
extern void* Java_com_epam_drill_session_DrillRequest_get(void* env, void* thiz, void* key);
extern drill_agent_KUInt Java_com_epam_drill_session_DrillRequest_RetransformClasses(void* env, void* thiz, drill_agent_KInt count, void* classes);
extern void* Java_com_epam_drill_session_DrillRequest_GetAllLoadedClasses(void* env, void* thiz);
extern void jvmtiEventClassFileLoadHookEvent(void* jvmtiEnv, void* jniEnv, void* classBeingRedefined, void* loader, const char* kClassName, void* protection_domain, drill_agent_KInt classDataLen, void* classData, void* newClassDataLen, void* newData);
extern void jvmtiEventNativeMethodBindEvent(void* jvmtiEnv, void* jniEnv, void* thread, void* method, void* address, void* newAddressPtr);
extern void jvmtiEventVMInitEvent(void* env, void* jniEnv, void* thread);

typedef struct {
  /* Service functions. */
  void (*DisposeStablePointer)(drill_agent_KNativePtr ptr);
  void (*DisposeString)(const char* string);
  drill_agent_KBoolean (*IsInstance)(drill_agent_KNativePtr ref, const drill_agent_KType* type);
  drill_agent_kref_kotlin_Byte (*createNullableByte)(drill_agent_KByte);
  drill_agent_kref_kotlin_Short (*createNullableShort)(drill_agent_KShort);
  drill_agent_kref_kotlin_Int (*createNullableInt)(drill_agent_KInt);
  drill_agent_kref_kotlin_Long (*createNullableLong)(drill_agent_KLong);
  drill_agent_kref_kotlin_Float (*createNullableFloat)(drill_agent_KFloat);
  drill_agent_kref_kotlin_Double (*createNullableDouble)(drill_agent_KDouble);
  drill_agent_kref_kotlin_Char (*createNullableChar)(drill_agent_KChar);
  drill_agent_kref_kotlin_Boolean (*createNullableBoolean)(drill_agent_KBoolean);
  drill_agent_kref_kotlin_Unit (*createNullableUnit)(void);

  /* User functions. */
  struct {
    struct {
      struct {
        struct {
          struct {
            drill_agent_KInt (*get_size)(drill_agent_kref_com_epam_drill_MemBuffer thiz);
            drill_agent_KInt (*get_size_)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz);
            drill_agent_KInt (*get_size__)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz);
            drill_agent_KByte (*getByte)(drill_agent_kref_com_epam_drill_MemBuffer thiz, drill_agent_KInt index);
            drill_agent_KShort (*getShort)(drill_agent_kref_com_epam_drill_MemBuffer thiz, drill_agent_KInt index);
            drill_agent_KInt (*getInt)(drill_agent_kref_com_epam_drill_MemBuffer thiz, drill_agent_KInt index);
            drill_agent_KFloat (*getFloat)(drill_agent_kref_com_epam_drill_MemBuffer thiz, drill_agent_KInt index);
            drill_agent_KDouble (*getDouble)(drill_agent_kref_com_epam_drill_MemBuffer thiz, drill_agent_KInt index);
            void (*setByte)(drill_agent_kref_com_epam_drill_MemBuffer thiz, drill_agent_KInt index, drill_agent_KByte value);
            void (*setShort)(drill_agent_kref_com_epam_drill_MemBuffer thiz, drill_agent_KInt index, drill_agent_KShort value);
            void (*setInt)(drill_agent_kref_com_epam_drill_MemBuffer thiz, drill_agent_KInt index, drill_agent_KInt value);
            void (*setFloat)(drill_agent_kref_com_epam_drill_MemBuffer thiz, drill_agent_KInt index, drill_agent_KFloat value);
            void (*setDouble)(drill_agent_kref_com_epam_drill_MemBuffer thiz, drill_agent_KInt index, drill_agent_KDouble value);
            drill_agent_KByte (*get)(drill_agent_kref_com_epam_drill_Int8Buffer thiz, drill_agent_KInt index);
            drill_agent_KShort (*get_)(drill_agent_kref_com_epam_drill_Int16Buffer thiz, drill_agent_KInt index);
            drill_agent_KInt (*get__)(drill_agent_kref_com_epam_drill_Int32Buffer thiz, drill_agent_KInt index);
            drill_agent_KFloat (*get___)(drill_agent_kref_com_epam_drill_Float32Buffer thiz, drill_agent_KInt index);
            drill_agent_KDouble (*get____)(drill_agent_kref_com_epam_drill_Float64Buffer thiz, drill_agent_KInt index);
            void (*set)(drill_agent_kref_com_epam_drill_Int8Buffer thiz, drill_agent_KInt index, drill_agent_KByte value);
            void (*set_)(drill_agent_kref_com_epam_drill_Int16Buffer thiz, drill_agent_KInt index, drill_agent_KShort value);
            void (*set__)(drill_agent_kref_com_epam_drill_Int32Buffer thiz, drill_agent_KInt index, drill_agent_KInt value);
            void (*set___)(drill_agent_kref_com_epam_drill_Float32Buffer thiz, drill_agent_KInt index, drill_agent_KFloat value);
            void (*set____)(drill_agent_kref_com_epam_drill_Float64Buffer thiz, drill_agent_KInt index, drill_agent_KDouble value);
            void (*append)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz, drill_agent_kref_kotlin_ByteArray array, drill_agent_KInt offset, drill_agent_KInt len);
            drill_agent_kref_com_epam_drill_ByteArrayBuilder (*append_)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz, drill_agent_KByte v);
            void (*append__)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz, drill_agent_kref_kotlin_ByteArray v);
            drill_agent_kref_com_epam_drill_ByteArrayBuilder (*append___)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz, drill_agent_kref_kotlin_IntArray v);
            void (*append____)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz, drill_agent_kref_kotlin_ByteArray array, drill_agent_KInt offset, drill_agent_KInt len);
            drill_agent_kref_com_epam_drill_ByteArrayBuilder (*append_____)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz, drill_agent_KByte v);
            void (*append______)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz, drill_agent_kref_kotlin_ByteArray v);
            drill_agent_kref_com_epam_drill_ByteArrayBuilder (*append_______)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz, drill_agent_kref_kotlin_IntArray v);
            drill_agent_KInt (*readU8)(drill_agent_kref_kotlin_ByteArray thiz, drill_agent_KInt o);
            drill_agent_KInt (*readU16BE)(drill_agent_kref_kotlin_ByteArray thiz, drill_agent_KInt o);
            drill_agent_KInt (*readU24BE)(drill_agent_kref_kotlin_ByteArray thiz, drill_agent_KInt o);
            drill_agent_KInt (*readS32BE)(drill_agent_kref_kotlin_ByteArray thiz, drill_agent_KInt o);
            struct {
              drill_agent_KType* (*_type)(void);
              drill_agent_kref_com_epam_drill_AgentPluginData (*_instance)();
              drill_agent_kref_kotlin_collections_Map (*get_classMap)(drill_agent_kref_com_epam_drill_AgentPluginData thiz);
              void (*set_classMap)(drill_agent_kref_com_epam_drill_AgentPluginData thiz, drill_agent_kref_kotlin_collections_Map set);
            } AgentPluginData;
            struct {
              drill_agent_KType* (*_type)(void);
              drill_agent_kref_com_epam_drill_MemBuffer (*MemBuffer)(drill_agent_kref_kotlin_ByteArray data);
              drill_agent_kref_kotlin_ByteArray (*get_data)(drill_agent_kref_com_epam_drill_MemBuffer thiz);
            } MemBuffer;
            struct {
              drill_agent_KType* (*_type)(void);
              drill_agent_kref_com_epam_drill_Int8Buffer (*Int8Buffer)(drill_agent_kref_com_epam_drill_MemBuffer mbuffer, drill_agent_KInt byteOffset, drill_agent_KInt size);
              drill_agent_KInt (*getByteIndex)(drill_agent_kref_com_epam_drill_Int8Buffer thiz, drill_agent_KInt index);
              drill_agent_kref_com_epam_drill_MemBuffer (*get_mbuffer)(drill_agent_kref_com_epam_drill_Int8Buffer thiz);
              drill_agent_KInt (*get_byteOffset)(drill_agent_kref_com_epam_drill_Int8Buffer thiz);
              drill_agent_KInt (*get_size)(drill_agent_kref_com_epam_drill_Int8Buffer thiz);
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_Int8Buffer_Companion (*_instance)();
                drill_agent_KInt (*get_SIZE)(drill_agent_kref_com_epam_drill_Int8Buffer_Companion thiz);
              } Companion;
            } Int8Buffer;
            struct {
              drill_agent_KType* (*_type)(void);
              drill_agent_kref_com_epam_drill_Int16Buffer (*Int16Buffer)(drill_agent_kref_com_epam_drill_MemBuffer mbuffer, drill_agent_KInt byteOffset, drill_agent_KInt size);
              drill_agent_KInt (*getByteIndex)(drill_agent_kref_com_epam_drill_Int16Buffer thiz, drill_agent_KInt index);
              drill_agent_kref_com_epam_drill_MemBuffer (*get_mbuffer)(drill_agent_kref_com_epam_drill_Int16Buffer thiz);
              drill_agent_KInt (*get_byteOffset)(drill_agent_kref_com_epam_drill_Int16Buffer thiz);
              drill_agent_KInt (*get_size)(drill_agent_kref_com_epam_drill_Int16Buffer thiz);
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_Int16Buffer_Companion (*_instance)();
                drill_agent_KInt (*get_SIZE)(drill_agent_kref_com_epam_drill_Int16Buffer_Companion thiz);
              } Companion;
            } Int16Buffer;
            struct {
              drill_agent_KType* (*_type)(void);
              drill_agent_kref_com_epam_drill_Int32Buffer (*Int32Buffer)(drill_agent_kref_com_epam_drill_MemBuffer mbuffer, drill_agent_KInt byteOffset, drill_agent_KInt size);
              drill_agent_KInt (*getByteIndex)(drill_agent_kref_com_epam_drill_Int32Buffer thiz, drill_agent_KInt index);
              drill_agent_kref_com_epam_drill_MemBuffer (*get_mbuffer)(drill_agent_kref_com_epam_drill_Int32Buffer thiz);
              drill_agent_KInt (*get_byteOffset)(drill_agent_kref_com_epam_drill_Int32Buffer thiz);
              drill_agent_KInt (*get_size)(drill_agent_kref_com_epam_drill_Int32Buffer thiz);
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_Int32Buffer_Companion (*_instance)();
                drill_agent_KInt (*get_SIZE)(drill_agent_kref_com_epam_drill_Int32Buffer_Companion thiz);
              } Companion;
            } Int32Buffer;
            struct {
              drill_agent_KType* (*_type)(void);
              drill_agent_kref_com_epam_drill_Float32Buffer (*Float32Buffer)(drill_agent_kref_com_epam_drill_MemBuffer mbuffer, drill_agent_KInt byteOffset, drill_agent_KInt size);
              drill_agent_KInt (*getByteIndex)(drill_agent_kref_com_epam_drill_Float32Buffer thiz, drill_agent_KInt index);
              drill_agent_kref_com_epam_drill_MemBuffer (*get_mbuffer)(drill_agent_kref_com_epam_drill_Float32Buffer thiz);
              drill_agent_KInt (*get_byteOffset)(drill_agent_kref_com_epam_drill_Float32Buffer thiz);
              drill_agent_KInt (*get_size)(drill_agent_kref_com_epam_drill_Float32Buffer thiz);
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_Float32Buffer_Companion (*_instance)();
                drill_agent_KInt (*get_SIZE)(drill_agent_kref_com_epam_drill_Float32Buffer_Companion thiz);
              } Companion;
            } Float32Buffer;
            struct {
              drill_agent_KType* (*_type)(void);
              drill_agent_kref_com_epam_drill_Float64Buffer (*Float64Buffer)(drill_agent_kref_com_epam_drill_MemBuffer mbuffer, drill_agent_KInt byteOffset, drill_agent_KInt size);
              drill_agent_KInt (*getByteIndex)(drill_agent_kref_com_epam_drill_Float64Buffer thiz, drill_agent_KInt index);
              drill_agent_kref_com_epam_drill_MemBuffer (*get_mbuffer)(drill_agent_kref_com_epam_drill_Float64Buffer thiz);
              drill_agent_KInt (*get_byteOffset)(drill_agent_kref_com_epam_drill_Float64Buffer thiz);
              drill_agent_KInt (*get_size)(drill_agent_kref_com_epam_drill_Float64Buffer thiz);
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_Float64Buffer_Companion (*_instance)();
                drill_agent_KInt (*get_SIZE)(drill_agent_kref_com_epam_drill_Float64Buffer_Companion thiz);
              } Companion;
            } Float64Buffer;
            struct {
              drill_agent_KType* (*_type)(void);
              drill_agent_kref_com_epam_drill_ByteArrayBuilder (*ByteArrayBuilder)(drill_agent_KInt initialCapacity);
              drill_agent_kref_com_epam_drill_ByteArrayBuilder (*ByteArrayBuilder_)(drill_agent_kref_kotlin_ByteArray data, drill_agent_KInt size, drill_agent_KBoolean allowGrow);
              drill_agent_KInt (*get_size)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz);
              void (*set_size)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz, drill_agent_KInt value);
              void (*arrayfill)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz, drill_agent_kref_kotlin_ByteArray array, drill_agent_KByte value, drill_agent_KInt start, drill_agent_KInt end);
              void (*append)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz, drill_agent_kref_kotlin_ByteArray array, drill_agent_KInt offset, drill_agent_KInt len);
              drill_agent_kref_com_epam_drill_ByteArrayBuilder (*append_)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz, drill_agent_KByte v);
              void (*append__)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz, drill_agent_kref_kotlin_ByteArray v);
              drill_agent_kref_com_epam_drill_ByteArrayBuilder (*append___)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz, drill_agent_kref_kotlin_IntArray v);
              drill_agent_kref_kotlin_ByteArray (*toByteArray)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz);
              drill_agent_kref_kotlin_ByteArray (*get_data)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz);
              void (*set_data)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz, drill_agent_kref_kotlin_ByteArray set);
              drill_agent_KBoolean (*get_allowGrow)(drill_agent_kref_com_epam_drill_ByteArrayBuilder thiz);
            } ByteArrayBuilder;
            struct {
              void* (*JNIFun_)();
              void* (*JNIEn_)();
              void (*sendToSocket_)(const char* pluginId, const char* message);
              void* (*currentThread_)();
              drill_agent_kref_com_epam_drill_plugin_DrillRequest (*drillRequest_)();
              void* (*drillCRequest)(void* thread);
              void* (*jvmti)();
              void (*jvmti_)(drill_agent_kref_kotlinx_cinterop_CValuesRef callbacks, drill_agent_KInt size_of_callbacks);
              void* (*jvmtiCallback)();
              void (*enableJvmtiEventBreakpoint_)(void* thread);
              void (*enableJvmtiEventClassFileLoadHook_)(void* thread);
              void (*enableJvmtiEventClassLoad_)(void* thread);
              void (*enableJvmtiEventClassPrepare_)(void* thread);
              void (*enableJvmtiEventCompiledMethodLoad_)(void* thread);
              void (*enableJvmtiEventCompiledMethodUnload_)(void* thread);
              void (*enableJvmtiEventDataDumpRequest_)(void* thread);
              void (*enableJvmtiEventDynamicCodeGenerated_)(void* thread);
              void (*enableJvmtiEventException_)(void* thread);
              void (*enableJvmtiEventExceptionCatch_)(void* thread);
              void (*enableJvmtiEventFieldAccess_)(void* thread);
              void (*enableJvmtiEventFieldModification_)(void* thread);
              void (*enableJvmtiEventFramePop_)(void* thread);
              void (*enableJvmtiEventGarbageCollectionFinish_)(void* thread);
              void (*enableJvmtiEventGarbageCollectionStart_)(void* thread);
              void (*enableJvmtiEventMethodEntry_)(void* thread);
              void (*enableJvmtiEventMethodExit_)(void* thread);
              void (*enableJvmtiEventMonitorContendedEnter_)(void* thread);
              void (*enableJvmtiEventMonitorContendedEntered_)(void* thread);
              void (*enableJvmtiEventMonitorWait_)(void* thread);
              void (*enableJvmtiEventMonitorWaited_)(void* thread);
              void (*enableJvmtiEventNativeMethodBind_)(void* thread);
              void (*enableJvmtiEventObjectFree_)(void* thread);
              void (*enableJvmtiEventResourceExhausted_)(void* thread);
              void (*enableJvmtiEventSingleStep_)(void* thread);
              void (*enableJvmtiEventThreadEnd_)(void* thread);
              void (*enableJvmtiEventThreadStart_)(void* thread);
              void (*enableJvmtiEventVmDeath_)(void* thread);
              void (*enableJvmtiEventVmInit_)(void* thread);
              void (*enableJvmtiEventVmObjectAlloc_)(void* thread);
              void (*enableJvmtiEventVmStart_)(void* thread);
              void (*disableJvmtiEventBreakpoint_)(void* thread);
              void (*disableJvmtiEventClassFileLoadHook_)(void* thread);
              void (*disableJvmtiEventClassLoad_)(void* thread);
              void (*disableJvmtiEventClassPrepare_)(void* thread);
              void (*disableJvmtiEventCompiledMethodLoad_)(void* thread);
              void (*disableJvmtiEventCompiledMethodUnload_)(void* thread);
              void (*disableJvmtiEventDataDumpRequest_)(void* thread);
              void (*disableJvmtiEventDynamicCodeGenerated_)(void* thread);
              void (*disableJvmtiEventException_)(void* thread);
              void (*disableJvmtiEventExceptionCatch_)(void* thread);
              void (*disableJvmtiEventFieldAccess_)(void* thread);
              void (*disableJvmtiEventFieldModification_)(void* thread);
              void (*disableJvmtiEventFramePop_)(void* thread);
              void (*disableJvmtiEventGarbageCollectionFinish_)(void* thread);
              void (*disableJvmtiEventGarbageCollectionStart_)(void* thread);
              void (*disableJvmtiEventMethodEntry_)(void* thread);
              void (*disableJvmtiEventMethodExit_)(void* thread);
              void (*disableJvmtiEventMonitorContendedEnter_)(void* thread);
              void (*disableJvmtiEventMonitorContendedEntered_)(void* thread);
              void (*disableJvmtiEventMonitorWait_)(void* thread);
              void (*disableJvmtiEventMonitorWaited_)(void* thread);
              void (*disableJvmtiEventNativeMethodBind_)(void* thread);
              void (*disableJvmtiEventObjectFree_)(void* thread);
              void (*disableJvmtiEventResourceExhausted_)(void* thread);
              void (*disableJvmtiEventSingleStep_)(void* thread);
              void (*disableJvmtiEventThreadEnd_)(void* thread);
              void (*disableJvmtiEventThreadStart_)(void* thread);
              void (*disableJvmtiEventVmDeath_)(void* thread);
              void (*disableJvmtiEventVmInit_)(void* thread);
              void (*disableJvmtiEventVmObjectAlloc_)(void* thread);
              void (*disableJvmtiEventVmStart_)(void* thread);
              drill_agent_kref_com_epam_drill_plugin_api_processing_NativePart (*getPlugin_)(void* id);
              void (*addPluginToRegistry_)(drill_agent_kref_com_epam_drill_plugin_api_processing_NativePart plugin);
            } api;
            struct {
              drill_agent_kref_kotlin_collections_ArrayList (*fastIterateRemove)(drill_agent_kref_kotlin_collections_ArrayList thiz, drill_agent_kref_kotlin_Function1 callback);
              void (*invoke)(drill_agent_kref_com_epam_drill_async_Signal thiz);
            } async;
            struct {
              drill_agent_KInt (*get_work)();
              drill_agent_kref_com_epam_drill_core_DI (*get_dsa)();
              drill_agent_KInt (*agentOnLoad)(void* vmPointer, const char* options, drill_agent_KLong reservedPtr);
              drill_agent_kref_kotlin_collections_Map (*asAgentParams)(const char* thiz);
              void (*vmDeathEvent)(void* jvmtiEnv, void* jniEnv);
              void (*agentOnUnload)(void* vmPointer);
              const char* (*get_drillInstallationDir)();
              void* (*currentEnvs_)();
              void* (*jvmtii_)();
              drill_agent_KUInt (*checkEx_)(drill_agent_KUInt errCode, const char* funName);
              void (*sendFromJava)(void* env, void* thiz, void* pluginId, void* message);
              void* (*currentsession4java)(void* env, void* thiz);
              void* (*getHeader4java)(void* env, void* thiz, void* key);
              drill_agent_KUInt (*RetransformClasses)(void* env, void* thiz, drill_agent_KInt count, void* classes);
              void* (*GetAllLoadedClasses)(void* env, void* thiz);
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_core_DI (*DI)();
                drill_agent_kref_com_epam_drill_common_ws_URL (*get_adminAddress)(drill_agent_kref_com_epam_drill_core_DI thiz);
                void (*set_adminAddress)(drill_agent_kref_com_epam_drill_core_DI thiz, drill_agent_kref_com_epam_drill_common_ws_URL set);
                drill_agent_kref_com_epam_drill_common_ws_URL (*get_secureAdminAddress)(drill_agent_kref_com_epam_drill_core_DI thiz);
                void (*set_secureAdminAddress)(drill_agent_kref_com_epam_drill_core_DI thiz, drill_agent_kref_com_epam_drill_common_ws_URL set);
                drill_agent_kref_com_epam_drill_common_AgentConfig (*get_agentConfig)(drill_agent_kref_com_epam_drill_core_DI thiz);
                void (*set_agentConfig)(drill_agent_kref_com_epam_drill_core_DI thiz, drill_agent_kref_com_epam_drill_common_AgentConfig set);
                const char* (*get_drillInstallationDir)(drill_agent_kref_com_epam_drill_core_DI thiz);
                void (*set_drillInstallationDir)(drill_agent_kref_com_epam_drill_core_DI thiz, const char* set);
                drill_agent_kref_kotlin_collections_MutableMap (*get_pstorage)(drill_agent_kref_com_epam_drill_core_DI thiz);
                void (*set_pstorage)(drill_agent_kref_com_epam_drill_core_DI thiz, drill_agent_kref_kotlin_collections_MutableMap set);
                drill_agent_kref_com_epam_drill_core_DI_NativeMethodBinder (*get_originalMethod)(drill_agent_kref_com_epam_drill_core_DI thiz);
                drill_agent_kref_kotlin_collections_MutableMap (*get_objects)(drill_agent_kref_com_epam_drill_core_DI thiz);
                drill_agent_kref_kotlin_collections_MutableMap (*get_pl)(drill_agent_kref_com_epam_drill_core_DI thiz);
                void (*singleton)(drill_agent_kref_com_epam_drill_core_DI thiz, drill_agent_kref_kotlin_Any obj);
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_DI_NativeMethodBinder (*NativeMethodBinder)();
                  drill_agent_kref_kotlin_collections_MutableMap (*get_misfeatureToFunctionDictionary)(drill_agent_kref_com_epam_drill_core_DI_NativeMethodBinder thiz);
                  void* (*get)(drill_agent_kref_com_epam_drill_core_DI_NativeMethodBinder thiz, drill_agent_kref_kotlin_reflect_KFunction2 targetFunction);
                  void* (*get_)(drill_agent_kref_com_epam_drill_core_DI_NativeMethodBinder thiz, drill_agent_kref_kotlin_reflect_KFunction3 targetFunction);
                  void* (*get__)(drill_agent_kref_com_epam_drill_core_DI_NativeMethodBinder thiz, drill_agent_kref_kotlin_reflect_KFunction4 targetFunction);
                  void* (*get___)(drill_agent_kref_com_epam_drill_core_DI_NativeMethodBinder thiz, drill_agent_kref_kotlin_reflect_KFunction5 targetFunction);
                  void* (*get____)(drill_agent_kref_com_epam_drill_core_DI_NativeMethodBinder thiz, drill_agent_kref_kotlin_reflect_KFunction6 targetFunction);
                } NativeMethodBinder;
              } DI;
              struct {
                void (*performAgentInitialization)(drill_agent_kref_kotlin_collections_Map initialParams);
                void (*calculateBuildVersion)();
                drill_agent_kref_kotlin_collections_List (*getClassesByConfig)();
                void (*setPackagesPrefixes)(const char* prefixes);
              } agent;
              struct {
                struct {
                  void (*classLoadEvent)(void* jvmtiEnv, void* jniEnv, void* classBeingRedefined, void* loader, const char* kClassName, void* protection_domain, drill_agent_KInt classDataLen, void* classData, void* newClassDataLen, void* newData);
                } classloading;
                struct {
                  void (*nativeMethodBind)(void* jvmtiEnv, void* jniEnv, void* thread, void* method, void* address, void* newAddressPtr);
                  drill_agent_kref_kotlin_collections_Map (*get_nativeMethodBindMapper)();
                  const char* (*get_SocketDispatcher)();
                  const char* (*get_FileDispatcherImpl)();
                  const char* (*get_Netty)();
                  drill_agent_KInt (*readAddress)(void* env, void* clazz, drill_agent_KInt fd, drill_agent_KLong address, drill_agent_KInt pos, drill_agent_KInt limit);
                  drill_agent_KInt (*read0)(void* env, void* obj, void* fd, drill_agent_KLong address, drill_agent_KInt len);
                  void (*fillRequestToHolder)(const char* request);
                  const char* (*sessionId)();
                  drill_agent_KInt (*readv0)(void* env, void* obj, void* fd, drill_agent_KLong address, drill_agent_KInt len);
                  drill_agent_KInt (*write0)(void* env, void* obj, void* fd, drill_agent_KLong address, drill_agent_KInt len);
                  drill_agent_KInt (*writeAddress)(void* env, void* clazz, drill_agent_KInt fd, drill_agent_KLong address, drill_agent_KInt pos, drill_agent_KInt len);
                  drill_agent_KInt (*write)(drill_agent_KLong address, drill_agent_KInt len, drill_agent_kref_kotlin_Function2 block);
                  void* (*toPointer)(drill_agent_KLong thiz);
                  drill_agent_kref_kotlin_ByteArray (*readBytes)(drill_agent_KLong thiz, drill_agent_KInt end);
                  const char* (*rawString)(drill_agent_KLong thiz, drill_agent_KInt end);
                } methodbind;
                struct {
                  void (*jvmtiEventVMInitEvent_)(void* env, void* jniEnv, void* thread);
                } vminit;
              } callbacks;
              struct {
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_concurrency_Symbol (*Symbol)(const char* s);
                } Symbol;
              } concurrency;
              struct {
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_exceptions_PluginLoadException (*PluginLoadException)(const char* message);
                } PluginLoadException;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_exceptions_WsClosedException (*WsClosedException)(const char* message);
                } WsClosedException;
              } exceptions;
              struct {
                void (*sendNativeMessage)(void* pluginId, void* content);
                void (*sendMessage)(const char* pluginId, const char* content);
              } messanger;
              struct {
                drill_agent_kref_com_epam_drill_common_PluginMetadata (*pluginConfigById)(const char* pluginId);
                drill_agent_kref_kotlin_collections_MutableMap (*get_storage)();
                drill_agent_kref_com_epam_drill_common_PluginMetadata (*actualPluginConfig)(drill_agent_kref_com_epam_drill_plugin_api_processing_AgentPart thiz);
                struct {
                  struct {
                    drill_agent_KType* (*_type)(void);
                    drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage (*DrillMessage)(drill_agent_KInt seen1, const char* sessionId, const char* content, drill_agent_kref_kotlinx_serialization_SerializationConstructorMarker serializationConstructorMarker);
                    drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage (*DrillMessage_)(const char* sessionId, const char* content);
                    const char* (*get_sessionId)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz);
                    void (*set_sessionId)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz, const char* set);
                    const char* (*get_content)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz);
                    void (*set_content)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz, const char* set);
                    drill_agent_KBoolean (*equals)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz, drill_agent_kref_kotlin_Any other);
                    drill_agent_KInt (*hashCode)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz);
                    const char* (*toString)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz);
                    const char* (*component1)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz);
                    const char* (*component2)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz);
                    drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage (*copy)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage thiz, const char* sessionId, const char* content);
                    struct {
                      drill_agent_KType* (*_type)(void);
                      drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_Companion (*_instance)();
                      drill_agent_kref_kotlinx_serialization_KSerializer (*serializer)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_Companion thiz);
                    } Companion;
                    struct {
                      drill_agent_KType* (*_type)(void);
                      drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_$serializer (*_instance)();
                      drill_agent_kref_kotlinx_serialization_SerialDescriptor (*get_descriptor)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_$serializer thiz);
                      drill_agent_kref_kotlin_Array (*childSerializers)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_$serializer thiz);
                      drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage (*deserialize)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_$serializer thiz, drill_agent_kref_kotlinx_serialization_Decoder decoder);
                      void (*serialize)(drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage_$serializer thiz, drill_agent_kref_kotlinx_serialization_Encoder encoder, drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage obj);
                    } $serializer;
                  } DrillMessage;
                  struct {
                    drill_agent_KType* (*_type)(void);
                    drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper (*MessageWrapper)(drill_agent_KInt seen1, const char* pluginId, drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage drillMessage, drill_agent_kref_kotlinx_serialization_SerializationConstructorMarker serializationConstructorMarker);
                    drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper (*MessageWrapper_)(const char* pluginId, drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage drillMessage);
                    const char* (*get_pluginId)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper thiz);
                    void (*set_pluginId)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper thiz, const char* set);
                    drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage (*get_drillMessage)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper thiz);
                    void (*set_drillMessage)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper thiz, drill_agent_kref_com_epam_drill_core_plugin_dto_DrillMessage set);
                    struct {
                      drill_agent_KType* (*_type)(void);
                      drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_Companion (*_instance)();
                      drill_agent_kref_kotlinx_serialization_KSerializer (*serializer)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_Companion thiz);
                    } Companion;
                    struct {
                      drill_agent_KType* (*_type)(void);
                      drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_$serializer (*_instance)();
                      drill_agent_kref_kotlinx_serialization_SerialDescriptor (*get_descriptor)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_$serializer thiz);
                      drill_agent_kref_kotlin_Array (*childSerializers)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_$serializer thiz);
                      drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper (*deserialize)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_$serializer thiz, drill_agent_kref_kotlinx_serialization_Decoder decoder);
                      void (*serialize)(drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper_$serializer thiz, drill_agent_kref_kotlinx_serialization_Encoder encoder, drill_agent_kref_com_epam_drill_core_plugin_dto_MessageWrapper obj);
                    } $serializer;
                  } MessageWrapper;
                } dto;
                struct {
                  drill_agent_kref_com_epam_drill_logger_DLogger (*get_plLogger)();
                  void (*loadPlugin)(const char* pluginFilePath, drill_agent_kref_com_epam_drill_common_PluginMetadata pluginConfig);
                  struct {
                    drill_agent_KType* (*_type)(void);
                    drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin (*GenericNativePlugin)(const char* pluginId, void* pluginApiClass, void* userPlugin, drill_agent_kref_com_epam_drill_common_PluginMetadata pluginConfig);
                    const char* (*get_id)(drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin thiz);
                    void (*on)(drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin thiz);
                    void (*off)(drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin thiz);
                    void (*load)(drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin thiz, drill_agent_KBoolean onImmediately);
                    void (*unload)(drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin thiz, drill_agent_kref_com_epam_drill_plugin_api_processing_UnloadReason unloadReason);
                    void (*updateRawConfig)(drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin thiz, drill_agent_kref_com_epam_drill_common_PluginConfig config);
                    void* (*get_pluginApiClass)(drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin thiz);
                    void* (*get_userPlugin)(drill_agent_kref_com_epam_drill_core_plugin_loader_GenericNativePlugin thiz);
                  } GenericNativePlugin;
                  struct {
                    drill_agent_KType* (*_type)(void);
                    drill_agent_kref_com_epam_drill_core_plugin_loader_InstrumentationNativePlugin (*InstrumentationNativePlugin)(const char* pluginId, void* pluginApiClass, void* userPlugin, drill_agent_kref_com_epam_drill_common_PluginMetadata pluginConfig, void* qs);
                    drill_agent_kref_kotlin_ByteArray (*instrument)(drill_agent_kref_com_epam_drill_core_plugin_loader_InstrumentationNativePlugin thiz, const char* className, drill_agent_kref_kotlin_ByteArray initialBytes);
                    void (*retransform)(drill_agent_kref_com_epam_drill_core_plugin_loader_InstrumentationNativePlugin thiz);
                  } InstrumentationNativePlugin;
                } loader;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_plugin_PluginManager (*_instance)();
                  void (*addPlugin)(drill_agent_kref_com_epam_drill_plugin_PluginManager thiz, drill_agent_kref_com_epam_drill_plugin_api_processing_AgentPart plugin);
                  drill_agent_kref_com_epam_drill_plugin_api_processing_AgentPart (*get)(drill_agent_kref_com_epam_drill_plugin_PluginManager thiz, const char* id);
                  drill_agent_kref_kotlin_collections_List (*get_)(drill_agent_kref_com_epam_drill_plugin_PluginManager thiz, drill_agent_kref_com_epam_drill_common_Family id);
                } PluginManager;
              } plugin;
              struct {
                drill_agent_kref_com_epam_drill_core_ws_AsyncStream (*openAsync)(drill_agent_kref_kotlin_ByteArray thiz);
                drill_agent_kref_com_epam_drill_core_ws_AsyncStream (*toAsyncStream)(drill_agent_kref_com_epam_drill_core_ws_AsyncStreamBase thiz, drill_agent_KLong position);
                drill_agent_kref_kotlinx_coroutines_Deferred (*asyncImmediately)(drill_agent_kref_kotlin_coroutines_CoroutineContext context, drill_agent_kref_kotlin_coroutines_SuspendFunction0 callback);
                drill_agent_kref_kotlinx_coroutines_Deferred (*asyncImmediately_)(drill_agent_kref_kotlinx_coroutines_CoroutineScope thiz, drill_agent_kref_kotlin_coroutines_SuspendFunction0 callback);
                void (*arraycopy)(drill_agent_kref_kotlin_ByteArray src, drill_agent_KInt srcPos, drill_agent_kref_kotlin_ByteArray dst, drill_agent_KInt dstPos, drill_agent_KInt size);
                drill_agent_kref_com_epam_drill_logger_DLogger (*get_topicLogger)();
                void (*topicRegister)();
                drill_agent_kref_com_epam_drill_core_ws_WsRouter_inners (*topic)(drill_agent_kref_com_epam_drill_core_ws_WsRouter thiz, const char* url);
                drill_agent_kref_com_epam_drill_logger_DLogger (*get_wsLogger)();
                drill_agent_KInt (*get_wsThread)();
                drill_agent_KInt (*get_sendWorker)();
                drill_agent_KInt (*get_loader)();
                void (*sendMessage)(const char* message);
                drill_agent_KLong (*get_DELAY)();
                void (*startWs)();
                const char* (*toHexString)(drill_agent_kref_kotlin_ByteArray thiz);
                drill_agent_KInt (*executeCoroutines)(drill_agent_KInt thiz, drill_agent_kref_kotlin_coroutines_SuspendFunction1 block);
                drill_agent_KInt (*mask)(drill_agent_KInt thiz);
                drill_agent_kref_kotlin_collections_List (*buildList)(drill_agent_kref_kotlin_Function1 callback);
                drill_agent_KInt (*extract)(drill_agent_KInt thiz, drill_agent_KInt offset, drill_agent_KInt count);
                drill_agent_KBoolean (*extract_)(drill_agent_KInt thiz, drill_agent_KInt offset);
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_MemoryAsyncStreamBase (*MemoryAsyncStreamBase)(drill_agent_kref_kotlin_ByteArray data);
                  drill_agent_KInt (*get_ilength)(drill_agent_kref_com_epam_drill_core_ws_MemoryAsyncStreamBase thiz);
                  void (*set_ilength)(drill_agent_kref_com_epam_drill_core_ws_MemoryAsyncStreamBase thiz, drill_agent_KInt set);
                  void (*checkPosition)(drill_agent_kref_com_epam_drill_core_ws_MemoryAsyncStreamBase thiz, drill_agent_KLong position);
                  const char* (*toString)(drill_agent_kref_com_epam_drill_core_ws_MemoryAsyncStreamBase thiz);
                  drill_agent_kref_kotlin_ByteArray (*get_data)(drill_agent_kref_com_epam_drill_core_ws_MemoryAsyncStreamBase thiz);
                  void (*set_data)(drill_agent_kref_com_epam_drill_core_ws_MemoryAsyncStreamBase thiz, drill_agent_kref_kotlin_ByteArray set);
                } MemoryAsyncStreamBase;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncOutputStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncBaseStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                  struct {
                    drill_agent_KType* (*_type)(void);
                    drill_agent_kref_com_epam_drill_core_ws_AsyncCloseable_Companion (*_instance)();
                  } Companion;
                } AsyncCloseable;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncInputStreamWithLength;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncGetPositionStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncPositionLengthStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncPositionStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_AsyncStream (*AsyncStream)(drill_agent_kref_com_epam_drill_core_ws_AsyncStreamBase base, drill_agent_KLong position);
                  drill_agent_kref_com_epam_drill_core_ws_AsyncStreamBase (*get_base)(drill_agent_kref_com_epam_drill_core_ws_AsyncStream thiz);
                  drill_agent_KLong (*get_position)(drill_agent_kref_com_epam_drill_core_ws_AsyncStream thiz);
                  void (*set_position)(drill_agent_kref_com_epam_drill_core_ws_AsyncStream thiz, drill_agent_KLong set);
                } AsyncStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncInvokable;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_AsyncThread (*AsyncThread)();
                  drill_agent_kref_kotlinx_coroutines_Deferred (*sync)(drill_agent_kref_com_epam_drill_core_ws_AsyncThread thiz, drill_agent_kref_kotlin_coroutines_CoroutineContext context, drill_agent_kref_kotlin_coroutines_SuspendFunction0 func);
                } AsyncThread;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_AsyncStreamBase (*AsyncStreamBase)();
                } AsyncStreamBase;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncRAInputStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncRAOutputStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncInputStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncLengthStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                } AsyncGetLengthStream;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_WsRouter (*_instance)();
                  drill_agent_kref_kotlin_collections_MutableMap (*get_mapper)(drill_agent_kref_com_epam_drill_core_ws_WsRouter thiz);
                  void (*invoke)(drill_agent_kref_com_epam_drill_core_ws_WsRouter thiz, drill_agent_kref_kotlin_Function1 alotoftopics);
                  drill_agent_kref_com_epam_drill_core_ws_Topic (*get)(drill_agent_kref_com_epam_drill_core_ws_WsRouter thiz, const char* topic);
                  struct {
                    drill_agent_KType* (*_type)(void);
                    drill_agent_kref_com_epam_drill_core_ws_WsRouter_inners (*inners)(const char* destination);
                    drill_agent_kref_com_epam_drill_core_ws_GenericTopic (*withGenericTopic)(drill_agent_kref_com_epam_drill_core_ws_WsRouter_inners thiz, drill_agent_kref_kotlinx_serialization_KSerializer des, drill_agent_kref_kotlin_coroutines_SuspendFunction1 block);
                    drill_agent_kref_com_epam_drill_core_ws_PluginTopic (*withPluginTopic)(drill_agent_kref_com_epam_drill_core_ws_WsRouter_inners thiz, drill_agent_kref_kotlin_coroutines_SuspendFunction2 block);
                    drill_agent_kref_com_epam_drill_core_ws_InfoTopic (*rawMessage)(drill_agent_kref_com_epam_drill_core_ws_WsRouter_inners thiz, drill_agent_kref_kotlin_coroutines_SuspendFunction1 block);
                    const char* (*get_destination)(drill_agent_kref_com_epam_drill_core_ws_WsRouter_inners thiz);
                  } inners;
                } WsRouter;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_Topic (*Topic)(const char* destination);
                  const char* (*get_destination)(drill_agent_kref_com_epam_drill_core_ws_Topic thiz);
                } Topic;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_InfoTopic (*InfoTopic)(const char* destination, drill_agent_kref_kotlin_coroutines_SuspendFunction1 block);
                  const char* (*get_destination)(drill_agent_kref_com_epam_drill_core_ws_InfoTopic thiz);
                  drill_agent_kref_kotlin_coroutines_SuspendFunction1 (*get_block)(drill_agent_kref_com_epam_drill_core_ws_InfoTopic thiz);
                } InfoTopic;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_core_ws_PluginTopic (*PluginTopic)(const char* destination, drill_agent_kref_kotlin_coroutines_SuspendFunction2 block);
                  const char* (*get_destination)(drill_agent_kref_com_epam_drill_core_ws_PluginTopic thiz);
                  drill_agent_kref_kotlin_coroutines_SuspendFunction2 (*get_block)(drill_agent_kref_com_epam_drill_core_ws_PluginTopic thiz);
                } PluginTopic;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_ws_WsFrame (*WsFrame)(drill_agent_kref_kotlin_ByteArray data, drill_agent_KInt type, drill_agent_KBoolean isFinal, drill_agent_KBoolean frameIsBinary);
                  drill_agent_kref_kotlin_ByteArray (*toByteArray)(drill_agent_kref_com_epam_drill_ws_WsFrame thiz);
                  drill_agent_kref_kotlin_ByteArray (*get_data)(drill_agent_kref_com_epam_drill_ws_WsFrame thiz);
                  drill_agent_KInt (*get_type)(drill_agent_kref_com_epam_drill_ws_WsFrame thiz);
                  drill_agent_KBoolean (*get_isFinal)(drill_agent_kref_com_epam_drill_ws_WsFrame thiz);
                  drill_agent_KBoolean (*get_frameIsBinary)(drill_agent_kref_com_epam_drill_ws_WsFrame thiz);
                  struct {
                    drill_agent_KType* (*_type)(void);
                    drill_agent_kref_com_epam_drill_ws_WsFrame_Companion (*_instance)();
                    drill_agent_kref_kotlin_ByteArray (*applyMask)(drill_agent_kref_com_epam_drill_ws_WsFrame_Companion thiz, drill_agent_kref_kotlin_ByteArray payload, drill_agent_kref_kotlin_ByteArray mask);
                  } Companion;
                } WsFrame;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_ws_RawSocketWebSocketClient (*RawSocketWebSocketClient)(drill_agent_kref_kotlin_coroutines_CoroutineContext coroutineContext, drill_agent_kref_com_epam_drill_net_AsyncClient client, drill_agent_kref_com_epam_drill_common_ws_URL url, drill_agent_kref_kotlin_collections_List protocols, const char* origin, const char* key, drill_agent_kref_kotlin_collections_Map param);
                  const char* (*get_host)(drill_agent_kref_com_epam_drill_ws_RawSocketWebSocketClient thiz);
                  drill_agent_KInt (*get_port)(drill_agent_kref_com_epam_drill_ws_RawSocketWebSocketClient thiz);
                  const char* (*get_path)(drill_agent_kref_com_epam_drill_ws_RawSocketWebSocketClient thiz);
                  drill_agent_KBoolean (*get_closed)(drill_agent_kref_com_epam_drill_ws_RawSocketWebSocketClient thiz);
                  void (*set_closed)(drill_agent_kref_com_epam_drill_ws_RawSocketWebSocketClient thiz, drill_agent_KBoolean set);
                  void (*close)(drill_agent_kref_com_epam_drill_ws_RawSocketWebSocketClient thiz, drill_agent_KInt code, const char* reason);
                  drill_agent_kref_kotlin_coroutines_CoroutineContext (*get_coroutineContext)(drill_agent_kref_com_epam_drill_ws_RawSocketWebSocketClient thiz);
                  drill_agent_kref_com_epam_drill_net_AsyncClient (*get_client)(drill_agent_kref_com_epam_drill_ws_RawSocketWebSocketClient thiz);
                  const char* (*get_origin)(drill_agent_kref_com_epam_drill_ws_RawSocketWebSocketClient thiz);
                  const char* (*get_key)(drill_agent_kref_com_epam_drill_ws_RawSocketWebSocketClient thiz);
                  drill_agent_kref_kotlin_collections_Map (*get_param)(drill_agent_kref_com_epam_drill_ws_RawSocketWebSocketClient thiz);
                } RawSocketWebSocketClient;
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_ws_WebSocketClient (*WebSocketClient)(const char* url, drill_agent_kref_kotlin_collections_List protocols);
                  drill_agent_kref_com_epam_drill_async_Signal (*get_onOpen)(drill_agent_kref_com_epam_drill_ws_WebSocketClient thiz);
                  drill_agent_kref_com_epam_drill_async_Signal (*get_onError)(drill_agent_kref_com_epam_drill_ws_WebSocketClient thiz);
                  drill_agent_kref_com_epam_drill_async_Signal (*get_onClose)(drill_agent_kref_com_epam_drill_ws_WebSocketClient thiz);
                  drill_agent_kref_kotlin_collections_MutableSet (*get_onBinaryMessage)(drill_agent_kref_com_epam_drill_ws_WebSocketClient thiz);
                  drill_agent_kref_kotlin_collections_MutableSet (*get_onStringMessage)(drill_agent_kref_com_epam_drill_ws_WebSocketClient thiz);
                  drill_agent_kref_kotlin_collections_MutableSet (*get_onAnyMessage)(drill_agent_kref_com_epam_drill_ws_WebSocketClient thiz);
                  void (*close)(drill_agent_kref_com_epam_drill_ws_WebSocketClient thiz, drill_agent_KInt code, const char* reason);
                  const char* (*get_url)(drill_agent_kref_com_epam_drill_ws_WebSocketClient thiz);
                  drill_agent_kref_kotlin_collections_List (*get_protocols)(drill_agent_kref_com_epam_drill_ws_WebSocketClient thiz);
                } WebSocketClient;
              } ws;
            } core;
            struct {
              drill_agent_kref_kotlin_ByteArray (*hash)(drill_agent_kref_kotlin_ByteArray thiz, drill_agent_kref_com_epam_drill_crypto_HashFactory algo);
              drill_agent_kref_kotlin_ByteArray (*md5)(drill_agent_kref_kotlin_ByteArray thiz);
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_crypto_HashFactory (*HashFactory)(drill_agent_kref_kotlin_Function0 create);
                drill_agent_kref_kotlin_ByteArray (*digest)(drill_agent_kref_com_epam_drill_crypto_HashFactory thiz, drill_agent_kref_kotlin_ByteArray data);
                drill_agent_kref_kotlin_Function0 (*get_create)(drill_agent_kref_com_epam_drill_crypto_HashFactory thiz);
              } HashFactory;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_crypto_Hash (*Hash)(drill_agent_KInt chunkSize, drill_agent_KInt digestSize);
                drill_agent_kref_com_epam_drill_crypto_Hash (*reset)(drill_agent_kref_com_epam_drill_crypto_Hash thiz);
                drill_agent_kref_com_epam_drill_crypto_Hash (*update)(drill_agent_kref_com_epam_drill_crypto_Hash thiz, drill_agent_kref_kotlin_ByteArray data, drill_agent_KInt offset, drill_agent_KInt count);
                drill_agent_kref_com_epam_drill_crypto_Hash (*update_)(drill_agent_kref_com_epam_drill_crypto_Hash thiz, drill_agent_kref_kotlin_ByteArray data);
                void (*digestOut)(drill_agent_kref_com_epam_drill_crypto_Hash thiz, drill_agent_kref_kotlin_ByteArray out);
                void (*coreReset)(drill_agent_kref_com_epam_drill_crypto_Hash thiz);
                drill_agent_kref_kotlin_ByteArray (*corePadding)(drill_agent_kref_com_epam_drill_crypto_Hash thiz, drill_agent_KLong totalWritten);
                void (*coreUpdate)(drill_agent_kref_com_epam_drill_crypto_Hash thiz, drill_agent_kref_kotlin_ByteArray chunk);
                void (*coreDigest)(drill_agent_kref_com_epam_drill_crypto_Hash thiz, drill_agent_kref_kotlin_ByteArray out);
                drill_agent_kref_kotlin_ByteArray (*digest)(drill_agent_kref_com_epam_drill_crypto_Hash thiz);
                drill_agent_KInt (*get_chunkSize)(drill_agent_kref_com_epam_drill_crypto_Hash thiz);
                drill_agent_KInt (*get_digestSize)(drill_agent_kref_com_epam_drill_crypto_Hash thiz);
              } Hash;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_crypto_MD5 (*MD5)();
                void (*coreReset)(drill_agent_kref_com_epam_drill_crypto_MD5 thiz);
                void (*coreUpdate)(drill_agent_kref_com_epam_drill_crypto_MD5 thiz, drill_agent_kref_kotlin_ByteArray chunk);
                drill_agent_kref_kotlin_ByteArray (*corePadding)(drill_agent_kref_com_epam_drill_crypto_MD5 thiz, drill_agent_KLong totalWritten);
                void (*coreDigest)(drill_agent_kref_com_epam_drill_crypto_MD5 thiz, drill_agent_kref_kotlin_ByteArray out);
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_crypto_MD5_Companion (*_instance)();
                } Companion;
              } MD5;
            } crypto;
            struct {
              drill_agent_kref_com_epam_drill_lang_Charset (*get_UTF8)();
              drill_agent_kref_kotlin_ByteArray (*toByteArray)(const char* thiz, drill_agent_kref_com_epam_drill_lang_Charset charset);
              const char* (*toString)(drill_agent_kref_kotlin_ByteArray thiz, drill_agent_kref_com_epam_drill_lang_Charset charset);
              void (*invalidOp)(const char* msg);
              void (*unsupported)();
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_lang_Charset (*Charset)(const char* name);
                void (*encode)(drill_agent_kref_com_epam_drill_lang_Charset thiz, drill_agent_kref_com_epam_drill_ByteArrayBuilder out, drill_agent_kref_kotlin_CharSequence src, drill_agent_KInt start, drill_agent_KInt end);
                void (*decode)(drill_agent_kref_com_epam_drill_lang_Charset thiz, drill_agent_kref_kotlin_text_StringBuilder out, drill_agent_kref_kotlin_ByteArray src, drill_agent_KInt start, drill_agent_KInt end);
                const char* (*get_name)(drill_agent_kref_com_epam_drill_lang_Charset thiz);
              } Charset;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_lang_UTC8CharsetBase (*UTC8CharsetBase)(const char* name);
                void (*encode)(drill_agent_kref_com_epam_drill_lang_UTC8CharsetBase thiz, drill_agent_kref_com_epam_drill_ByteArrayBuilder out, drill_agent_kref_kotlin_CharSequence src, drill_agent_KInt start, drill_agent_KInt end);
                void (*decode)(drill_agent_kref_com_epam_drill_lang_UTC8CharsetBase thiz, drill_agent_kref_kotlin_text_StringBuilder out, drill_agent_kref_kotlin_ByteArray src, drill_agent_KInt start, drill_agent_KInt end);
              } UTC8CharsetBase;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_lang_IOException (*IOException)(const char* msg);
              } IOException;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_lang_EOFException (*EOFException)(const char* msg);
              } EOFException;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_lang_InvalidOperationException (*InvalidOperationException)(const char* str);
              } InvalidOperationException;
            } lang;
            struct {
              const char* (*toLogDate)(drill_agent_kref_io_ktor_util_date_GMTDate thiz);
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_logger_DLogger (*DLogger)(const char* name);
                void (*warn)(drill_agent_kref_com_epam_drill_logger_DLogger thiz, drill_agent_kref_kotlin_Function0 function);
                void (*error)(drill_agent_kref_com_epam_drill_logger_DLogger thiz, drill_agent_kref_kotlin_Function0 function);
                void (*debug)(drill_agent_kref_com_epam_drill_logger_DLogger thiz, drill_agent_kref_kotlin_Function0 function);
                void (*info)(drill_agent_kref_com_epam_drill_logger_DLogger thiz, drill_agent_kref_kotlin_Function0 function);
                const char* (*get_name)(drill_agent_kref_com_epam_drill_logger_DLogger thiz);
              } DLogger;
            } logger;
            struct {
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_net_AsyncSocketFactory (*AsyncSocketFactory)();
              } AsyncSocketFactory;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_KBoolean (*get_connected)(drill_agent_kref_com_epam_drill_net_AsyncClient thiz);
                void (*disconnect)(drill_agent_kref_com_epam_drill_net_AsyncClient thiz);
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_net_AsyncClient_Companion (*_instance)();
                } Companion;
              } AsyncClient;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_net_NativeAsyncSocketFactory (*_instance)();
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_net_NativeAsyncSocketFactory_NativeAsyncClient (*NativeAsyncClient)(drill_agent_kref_com_epam_drill_net_NativeSocket socket);
                  void (*disconnect)(drill_agent_kref_com_epam_drill_net_NativeAsyncSocketFactory_NativeAsyncClient thiz);
                  drill_agent_KBoolean (*get_connected)(drill_agent_kref_com_epam_drill_net_NativeAsyncSocketFactory_NativeAsyncClient thiz);
                  drill_agent_kref_com_epam_drill_net_NativeSocket (*get_socket)(drill_agent_kref_com_epam_drill_net_NativeAsyncSocketFactory_NativeAsyncClient thiz);
                } NativeAsyncClient;
              } NativeAsyncSocketFactory;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_KBoolean (*get_connected)(drill_agent_kref_com_epam_drill_net_NativeSocket thiz);
                void (*connect)(drill_agent_kref_com_epam_drill_net_NativeSocket thiz, const char* host, drill_agent_KInt port);
                drill_agent_KInt (*tryRecv)(drill_agent_kref_com_epam_drill_net_NativeSocket thiz, drill_agent_kref_kotlin_ByteArray data, drill_agent_KInt offset, drill_agent_KInt count);
                void (*send)(drill_agent_kref_com_epam_drill_net_NativeSocket thiz, drill_agent_kref_kotlin_ByteArray data, drill_agent_KInt offset, drill_agent_KInt count);
                void (*close)(drill_agent_kref_com_epam_drill_net_NativeSocket thiz);
                void (*disconnect)(drill_agent_kref_com_epam_drill_net_NativeSocket thiz);
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_net_NativeSocket_Companion (*_instance)();
                  drill_agent_kref_com_epam_drill_net_NativeSocket (*invoke)(drill_agent_kref_com_epam_drill_net_NativeSocket_Companion thiz);
                } Companion;
              } NativeSocket;
            } net;
            struct {
              drill_agent_KInt (*get_unsigned)(drill_agent_KByte thiz);
              drill_agent_kref_com_epam_drill_stream_AsyncInputStreamWithLength (*combine)(drill_agent_kref_kotlin_collections_List thiz);
              drill_agent_kref_com_epam_drill_stream_AsyncInputStreamWithLength (*plus)(drill_agent_kref_com_epam_drill_stream_AsyncInputStreamWithLength thiz, drill_agent_kref_com_epam_drill_stream_AsyncInputStreamWithLength other);
              void (*writeBytes)(drill_agent_kref_com_epam_drill_stream_SyncOutputStream thiz, drill_agent_kref_kotlin_ByteArray data);
              void (*fastForEach)(drill_agent_kref_kotlin_collections_List thiz, drill_agent_kref_kotlin_Function1 callback);
              drill_agent_kref_com_epam_drill_stream_SyncStream (*MemorySyncStream)(drill_agent_kref_com_epam_drill_ByteArrayBuilder data);
              drill_agent_kref_kotlin_ByteArray (*MemorySyncStreamToByteArray)(drill_agent_KInt initialCapacity, drill_agent_kref_kotlin_Function1 callback);
              void (*write8)(drill_agent_kref_com_epam_drill_stream_SyncOutputStream thiz, drill_agent_KInt v);
              void (*write16BE)(drill_agent_kref_com_epam_drill_stream_SyncOutputStream thiz, drill_agent_KInt v);
              void (*write32BE)(drill_agent_kref_com_epam_drill_stream_SyncOutputStream thiz, drill_agent_KInt v);
              drill_agent_kref_com_epam_drill_stream_SyncStream (*toSyncStream)(drill_agent_kref_com_epam_drill_stream_SyncStreamBase thiz, drill_agent_KLong position);
              struct {
                drill_agent_KType* (*_type)(void);
              } AsyncCloseable;
              struct {
                drill_agent_KType* (*_type)(void);
              } AsyncBaseStream;
              struct {
                drill_agent_KType* (*_type)(void);
              } AsyncInputStream;
              struct {
                drill_agent_KType* (*_type)(void);
              } AsyncOutputStream;
              struct {
                drill_agent_KType* (*_type)(void);
              } AsyncGetPositionStream;
              struct {
                drill_agent_KType* (*_type)(void);
              } AsyncGetLengthStream;
              struct {
                drill_agent_KType* (*_type)(void);
              } AsyncInputStreamWithLength;
              struct {
                drill_agent_KType* (*_type)(void);
                void (*close)(drill_agent_kref_com_epam_drill_stream_Closeable thiz);
              } Closeable;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_KInt (*read)(drill_agent_kref_com_epam_drill_stream_SyncInputStream thiz, drill_agent_kref_kotlin_ByteArray buffer, drill_agent_KInt offset, drill_agent_KInt len);
                drill_agent_KInt (*read_)(drill_agent_kref_com_epam_drill_stream_SyncInputStream thiz);
              } SyncInputStream;
              struct {
                drill_agent_KType* (*_type)(void);
                void (*write)(drill_agent_kref_com_epam_drill_stream_SyncOutputStream thiz, drill_agent_kref_kotlin_ByteArray buffer, drill_agent_KInt offset, drill_agent_KInt len);
                void (*write_)(drill_agent_kref_com_epam_drill_stream_SyncOutputStream thiz, drill_agent_KInt byte);
                void (*flush)(drill_agent_kref_com_epam_drill_stream_SyncOutputStream thiz);
              } SyncOutputStream;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_KLong (*get_position)(drill_agent_kref_com_epam_drill_stream_SyncPositionStream thiz);
                void (*set_position)(drill_agent_kref_com_epam_drill_stream_SyncPositionStream thiz, drill_agent_KLong set);
              } SyncPositionStream;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_KLong (*get_length)(drill_agent_kref_com_epam_drill_stream_SyncLengthStream thiz);
                void (*set_length)(drill_agent_kref_com_epam_drill_stream_SyncLengthStream thiz, drill_agent_KLong set);
              } SyncLengthStream;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_KInt (*read)(drill_agent_kref_com_epam_drill_stream_SyncRAInputStream thiz, drill_agent_KLong position, drill_agent_kref_kotlin_ByteArray buffer, drill_agent_KInt offset, drill_agent_KInt len);
              } SyncRAInputStream;
              struct {
                drill_agent_KType* (*_type)(void);
                void (*write)(drill_agent_kref_com_epam_drill_stream_SyncRAOutputStream thiz, drill_agent_KLong position, drill_agent_kref_kotlin_ByteArray buffer, drill_agent_KInt offset, drill_agent_KInt len);
                void (*flush)(drill_agent_kref_com_epam_drill_stream_SyncRAOutputStream thiz);
              } SyncRAOutputStream;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_stream_SyncStreamBase (*SyncStreamBase)();
                drill_agent_kref_kotlin_ByteArray (*get_smallTemp)(drill_agent_kref_com_epam_drill_stream_SyncStreamBase thiz);
                drill_agent_KInt (*read)(drill_agent_kref_com_epam_drill_stream_SyncStreamBase thiz, drill_agent_KLong position, drill_agent_kref_kotlin_ByteArray buffer, drill_agent_KInt offset, drill_agent_KInt len);
                void (*write)(drill_agent_kref_com_epam_drill_stream_SyncStreamBase thiz, drill_agent_KLong position, drill_agent_kref_kotlin_ByteArray buffer, drill_agent_KInt offset, drill_agent_KInt len);
                drill_agent_KLong (*get_length)(drill_agent_kref_com_epam_drill_stream_SyncStreamBase thiz);
                void (*set_length)(drill_agent_kref_com_epam_drill_stream_SyncStreamBase thiz, drill_agent_KLong value);
                void (*close)(drill_agent_kref_com_epam_drill_stream_SyncStreamBase thiz);
              } SyncStreamBase;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_kotlin_collections_HashMap (*get_extra)(drill_agent_kref_com_epam_drill_stream_Extra thiz);
                void (*set_extra)(drill_agent_kref_com_epam_drill_stream_Extra thiz, drill_agent_kref_kotlin_collections_HashMap set);
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_stream_Extra_Mixin (*Mixin)(drill_agent_kref_kotlin_collections_HashMap extra);
                  drill_agent_kref_kotlin_collections_HashMap (*get_extra)(drill_agent_kref_com_epam_drill_stream_Extra_Mixin thiz);
                  void (*set_extra)(drill_agent_kref_com_epam_drill_stream_Extra_Mixin thiz, drill_agent_kref_kotlin_collections_HashMap set);
                } Mixin;
              } Extra;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_stream_SyncStream (*SyncStream)(drill_agent_kref_com_epam_drill_stream_SyncStreamBase base, drill_agent_KLong position);
                drill_agent_KInt (*read)(drill_agent_kref_com_epam_drill_stream_SyncStream thiz, drill_agent_kref_kotlin_ByteArray buffer, drill_agent_KInt offset, drill_agent_KInt len);
                drill_agent_KInt (*read_)(drill_agent_kref_com_epam_drill_stream_SyncStream thiz);
                void (*write)(drill_agent_kref_com_epam_drill_stream_SyncStream thiz, drill_agent_kref_kotlin_ByteArray buffer, drill_agent_KInt offset, drill_agent_KInt len);
                void (*write_)(drill_agent_kref_com_epam_drill_stream_SyncStream thiz, drill_agent_KInt byte);
                drill_agent_KLong (*get_length)(drill_agent_kref_com_epam_drill_stream_SyncStream thiz);
                void (*set_length)(drill_agent_kref_com_epam_drill_stream_SyncStream thiz, drill_agent_KLong value);
                void (*flush)(drill_agent_kref_com_epam_drill_stream_SyncStream thiz);
                void (*close)(drill_agent_kref_com_epam_drill_stream_SyncStream thiz);
                const char* (*toString)(drill_agent_kref_com_epam_drill_stream_SyncStream thiz);
                drill_agent_kref_com_epam_drill_stream_SyncStreamBase (*get_base)(drill_agent_kref_com_epam_drill_stream_SyncStream thiz);
                drill_agent_KLong (*get_position)(drill_agent_kref_com_epam_drill_stream_SyncStream thiz);
                void (*set_position)(drill_agent_kref_com_epam_drill_stream_SyncStream thiz, drill_agent_KLong set);
                drill_agent_kref_kotlin_collections_HashMap (*get_extra)(drill_agent_kref_com_epam_drill_stream_SyncStream thiz);
                void (*set_extra)(drill_agent_kref_com_epam_drill_stream_SyncStream thiz, drill_agent_kref_kotlin_collections_HashMap set);
              } SyncStream;
              struct {
                drill_agent_KType* (*_type)(void);
                drill_agent_kref_com_epam_drill_stream_MemorySyncStreamBase (*MemorySyncStreamBase)(drill_agent_kref_com_epam_drill_ByteArrayBuilder data);
                drill_agent_KInt (*get_ilength)(drill_agent_kref_com_epam_drill_stream_MemorySyncStreamBase thiz);
                void (*set_ilength)(drill_agent_kref_com_epam_drill_stream_MemorySyncStreamBase thiz, drill_agent_KInt value);
                drill_agent_KLong (*get_length)(drill_agent_kref_com_epam_drill_stream_MemorySyncStreamBase thiz);
                void (*set_length)(drill_agent_kref_com_epam_drill_stream_MemorySyncStreamBase thiz, drill_agent_KLong value);
                void (*checkPosition)(drill_agent_kref_com_epam_drill_stream_MemorySyncStreamBase thiz, drill_agent_KLong position);
                drill_agent_KInt (*read)(drill_agent_kref_com_epam_drill_stream_MemorySyncStreamBase thiz, drill_agent_KLong position, drill_agent_kref_kotlin_ByteArray buffer, drill_agent_KInt offset, drill_agent_KInt len);
                void (*write)(drill_agent_kref_com_epam_drill_stream_MemorySyncStreamBase thiz, drill_agent_KLong position, drill_agent_kref_kotlin_ByteArray buffer, drill_agent_KInt offset, drill_agent_KInt len);
                void (*arraycopy)(drill_agent_kref_com_epam_drill_stream_MemorySyncStreamBase thiz, drill_agent_kref_kotlin_ByteArray src, drill_agent_KInt srcPos, drill_agent_kref_kotlin_ByteArray dst, drill_agent_KInt dstPos, drill_agent_KInt size);
                void (*close)(drill_agent_kref_com_epam_drill_stream_MemorySyncStreamBase thiz);
                const char* (*toString)(drill_agent_kref_com_epam_drill_stream_MemorySyncStreamBase thiz);
                drill_agent_kref_com_epam_drill_ByteArrayBuilder (*get_data)(drill_agent_kref_com_epam_drill_stream_MemorySyncStreamBase thiz);
                void (*set_data)(drill_agent_kref_com_epam_drill_stream_MemorySyncStreamBase thiz, drill_agent_kref_com_epam_drill_ByteArrayBuilder set);
              } MemorySyncStreamBase;
            } stream;
            struct {
              struct {
                const char* (*toBase64)(drill_agent_kref_kotlin_ByteArray thiz);
                struct {
                  drill_agent_KType* (*_type)(void);
                  drill_agent_kref_com_epam_drill_util_encoding_Base64 (*_instance)();
                  const char* (*encode)(drill_agent_kref_com_epam_drill_util_encoding_Base64 thiz, drill_agent_kref_kotlin_ByteArray src);
                } Base64;
              } encoding;
            } util;
          } drill;
        } epam;
      } com;
    } root;
  } kotlin;
} drill_agent_ExportedSymbols;
extern drill_agent_ExportedSymbols* drill_agent_symbols(void);
#ifdef __cplusplus
}  /* extern "C" */
#endif
#endif  /* KONAN_DRILL_AGENT_H */
